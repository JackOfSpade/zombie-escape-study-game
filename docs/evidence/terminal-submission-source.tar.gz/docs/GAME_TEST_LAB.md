# Test Lab

The Test Lab is primarily an automated framework for coding agents (Codex, Claude Code and other shell-capable tools). Agents create or modify scenario files, load existing cases, run deterministic suites against the real engine, inspect structured failures and replay them after a code fix. No dev server, browser, AI service or manual setup is required. Repository instructions are in `AGENTS.md` and `CLAUDE.md`.

Each test uses a fresh synthetic memory-only world with actual engine/Planck physics. It never reads or writes real game saves, diagnostic history, learner records or ChatGPT credentials, and makes no study bridge/AI requests. The optional visual debugger at **http://127.0.0.1:5173/lab.html** (also linked in Settings and included in production builds) uses the same scenario format and runner.

## Automated agent workflow

```sh
# Discover existing test definitions as machine-readable data.
npm run --silent test:game -- --list --json -
# Select an existing case (substring match on scenario ID).
npm run --silent test:game -- --filter push-door --json -
# Create/edit a JSON fixture directly, then execute it without opening the game.
npm run --silent test:game -- --scenario tests/fixtures/gametest/drag-damage.json --json -
# Run the complete catalog and save replay artifacts, with JSON-only stdout.
npm run --silent test:agents
# Reproduce a case using its generated scenario artifact.
npm run --silent test:game -- --scenario .artifacts/game-tests/drag-damage.scenario.json --json -
```

Agents should author fixtures directly in `tests/fixtures/gametest/<unique-id>.json`, using an existing fixture or `src/gametest/presets.ts` as a starting point. Script actions and outcome assertions, reproduce the failure, fix code, then rerun the case and full suite. Both `test:agents` and normal `npm test` automatically load checked-in fixtures; no registration or UI export is necessary. Multiple `--scenario FILE` arguments run an explicit suite instead of the default catalog. `--filter` also works on that suite. Browser-local setups are not part of the repository catalog.

`--json -` writes one JSON document to stdout; diagnostics are in that document. Use `npm run --silent` to suppress npm's command banner. `--json PATH` writes a JSON file and keeps human-readable console output. `--artifacts DIRECTORY` writes `report.json` and `<id>.scenario.json` / `<id>.result.json` for each executed case, including successful cases. `test:agents` defaults to `.artifacts/game-tests`, ignored by Git. Outputs for selected IDs are overwritten on repeat runs; unrelated files are never deleted. **Read the current report** to identify the cases from the latest invocation; files from previously selected cases can remain.

The version 1 suite report contains:

- `summary`: `total`, `passed`, `failed`, `unverified`, `errors`.
- `results`: per-case status, seed, exact final/failing tick, checks (expected/actual/message), actions, final positions, `source`, complete validated `scenario`, and `replay` path when artifacts are enabled.
- `errors`: `{source, error}` for invalid files, duplicate IDs, world-construction failures or invocation errors. Independent cases continue running after individual input/construction failures. Valid scenarios that fail during construction also receive replay artifacts. Invalid raw input is not copied into replay artifacts.

`--list --json -` returns `{version: 1, scenarios: [{id, name, seed, maxTicks, simulation, source}], errors}`. Exit **0** means every selected case passed (or listing succeeded). Exit **1** means failure, an unverified/no-check case, invalid input/invocation, output error or no matching cases. A constructor failure is an error, not a passing or missing case. Reports are data; inspect results rather than treating the presence of a file as success.

For lower-level control, TypeScript tests can instantiate `new TestRunner(scenario, roadmap)`, call `advance(n)` or `run()`, and inspect `runner.game` / `report()`. `emptyScenario()` in `src/gametest/schema.ts` supplies a blank arena. Use `parseScenario` for validation; extend the typed schema/runner for new supported actions or queries instead of evaluating code from JSON.

The design follows Minecraft GameTest's pattern of a reusable structure, starting entities, scripted actions and time-bounded assertions: [official GameTest introduction and example](https://learn.microsoft.com/en-us/minecraft/creator/documents/gametestbuildyourfirstgametest?view=minecraft-bedrock-stable).

## Optional visual debugging

1. Load a built-in scenario or choose **Blank arena**. Building scenarios use a fixed seed and the normal generated layout/population.
2. Choose a placement tool and click the floor to spawn a player, NPC, zombie, furniture or hinged door. Paint walls/floors one cell at a time. Use the floor selector for other levels.
3. Select an entity to edit its coordinates, health, furniture dimensions/angle, door latch state or stair credential. Editing resets the run so results cannot be mistaken for a test of the previous setup.
4. **Step 1 tick**, **Step 30 ticks**, or **Play / pause** to observe. Focus the canvas for WASD, E and Space; Esc pauses. Keyboard actions are recorded against simulation ticks. **Run test** resets to the setup and replays those actions. **Reset** discards unsaved live recording edits.
5. Add assertions in **Scenario JSON** and apply it. **Run test** advances in small batches until a failure or deadline, leaving the final scene and exact failed tick visible. **Run all built-in tests** runs every built-in independently and retains the first failing scene if any fail.

The full-floor diagnostic view intentionally has no player fog-of-war. NPC decisions still use the game's normal visibility rules. **Game** simulation runs normal NPC behavior, zombies, combat, handling and physics. **Motor test** simulation disables game AI and applies scripted character motors using the same native body contacts/avoidance; use it for controlled queues and opposing traffic. Motor-test results do not establish normal NPC decision quality.

No assertions means **unverified**, never passed. Assertions do not replace human playtesting for feel, readability, sound or learning quality.

## Save, replay and share local fixtures

- **Save setup locally** keeps the newest 12 lab setups within a separate 2 MB library. It never touches the game's save keys. Built-ins remain available after reload.
- **Export setup** saves the initial scene and its authored actions/checks. **Export recording** also includes keyboard actions added during playback. Import either JSON to replay it.
- **Export result** includes the scenario, seed, action outcomes, check expectations/actual values, exact failing tick, and final entity positions.
- **Capture current layout as setup** converts current walls, positions, health and door poses into a fresh arena, clearing actions/checks. This is layout capture, not a full AI-memory or study-state checkpoint. Door frames remain frames rather than being captured as thin leaves.
- Explicit `checkpoint` actions exercise a JSON/physics boundary mid-run. They preserve synthetic game state and reset native caches without using game storage.

## Run after code changes

```sh
npm run test:game
npm run test:game -- --list
npm run test:game -- --filter following-traffic
npm run test:game -- --scenario /absolute/path/to/exported-setup.json
npm run test:game -- --json /tmp/game-test-results.json
```

The CLI exits nonzero for failures, malformed scenarios, unmatched filters and unverified/no-check setups. It uses the same definitions and runner as the visual lab. The normal `npm test` suite also runs all built-ins and checked-in JSON scenarios.

To turn a bug into a lasting regression:

1. Author a fixture directly with a fixed seed or small arena (or use the optional visual debugger). Prefer a small specific setup; keep an actual reported-world seed when geometry matters.
2. Add outcome checks that fail on the buggy behavior and pass after the fix. Assert forward progress and solid contact, for example, rather than only a particular internal variable.
3. Save the scenario as `tests/fixtures/gametest/<unique-id>.json`. Files there are automatically included in `npm run test:game` and `npm test`. They can be imported into the browser lab individually. `drag-damage.json` is the checked-in example.
4. Run the new case before and after the fix, then the full GameTest catalog and appropriate existing core/browser tests. For changes to this tool, run `tests/game-test.test.ts` and `tests/browser/game-test-lab.spec.ts` too.

Built-in examples live in `src/gametest/presets.ts`. The lab's **Run all built-in tests** runs that catalog; checked-in repository JSON fixtures and browser-local setups are additional sources and are not silently treated as built-ins.

## Forward layouts and barricade regressions

New live runs use `createPlayableGame`, which selects the forward-layout generator. It randomizes transverse divider positions and rear/forward door locations using a separate seeded RNG, retaining normal world RNG behavior. Every study room has a route toward the stairwell independent of its original entrance. Structural tests cover 64 seeds / 256 ordinary floors with original entries sealed and no southward search steps. These checks establish wall connectivity, not immunity to movable obstructions, zombies or voluntary backtracking.

For version 1 scenario compatibility, `template: "building"` defaults to the legacy geometry. Add `layout: "forward"` to test current fresh-run generation; `forward-room-exit.json` is the checked-in example. The lower-level `createGame` retains legacy geometry by default for existing captured tests/benchmarks and also accepts fourth argument `{layout: "forward"}`. Loading a saved game does not regenerate its floors or learning state. Restarting through the game retains learning and creates the new layout.

`vault-stacked-barricade.json` exercises adjacent furniture, native contacts and a mid-vault JSON/physics checkpoint. Vaults extend past every successive movable prop blocking the landing, stopping at the first safe gap; there is no object-count or arbitrary distance cap. Walls, closed doors, floor boundaries and occupied landings remain solid. Unit cases cover all five movable furniture types at multiple angles. NPC handling regressions cover conflicting restored plans, cooperative same-goal transport, progress toward handling/route goals, bounded retry and real egress blockers. Successful and failed human Space attempts are recorded in local run diagnostics.

## Performance investigations

`lag-seed-opening.json` reproduces thirty seconds of normal NPC/zombie activity using the reported lag seed and a stationary indoor player. Its outcome checks remain deterministic; a passing result alone does not establish smooth frame pacing. For timing comparisons, use fresh synthetic worlds, warm up each build, alternate old/new runs, and compare world-state equality as well as measured costs. Measure drawing on animation frames; a tight drawing loop can force GPU synchronization and misrepresent interactive frame costs.

The game records bounded local `performance` entries about every two seconds of active wall time. These contain FPS, slow-frame count, maximum frame interval, average/maximum engine/render/total work and entity counts. Pause and restart reset timing windows. Entries share the existing newest-three-run / 400-entry / 256 KB-per-run limits and are saved with normal diagnostic checkpoints; no real learner data is added to test fixtures.

## Scenario format

A version 1 scenario has a unique ID/name, seed, `template` (`arena` or `building`), `simulation` (`game` or `physics`), `maxTicks`, `startTime`, `naturalSpawns`, and lists named `entities`, `deleted`, `maps`, `actions` and `checks`. Every simulation tick is 1/30 second. Scenes run for at most 3,600 ticks. Timeline ticks start at 1; actions execute in array order before that tick's simulation step; assertions read the resulting world.

Entities use world-unit positions and floor numbers starting at zero. The player has ID `human`; other IDs are unique. Furniture `maxHp` can preserve its original strength independently of damaged `hp`. Entity `angle` is in degrees; a door swings between −70 and +70 degrees. Its width/height describe the frame. `released` unlocks the latch without animating it. Non-door furniture can rotate. Duplicate runtime spawns fail. Character and furniture counts are bounded. Empty arenas have fixed perimeter walls; enabling natural spawns opens the outside staging lane unless an explicit map overrides it. Natural spawning still follows the game's ten-second initial delay.

Maps contain `{ "floor": 0, "rows": [...] }`: exactly 34 strings of 44 cells, with `#` for walls and `.` for floor. Entity overrides replace matching generated IDs; `deleted` removes generated entities, but cannot remove the player.

Actions:

- `move`: `id`, `x`, `y` (−1 to +1); persists until another move action. Game mode controls only `human`; motor mode can control any character. A zero vector stops its motor. Movement updates facing before a same-tick vault.
- `door`, `grip`, `vault`: survivor `id` and `target` entity ID. They use the actual game's reach/interaction checks. A failed interaction fails the test. `vault` accepts target `auto` for the game's faced-surface selection.
- `spawn`: an `entity` specification, allowing timed arrivals.
- `checkpoint`: serialize/restore the synthetic world at a tick boundary.

Checks have `name`, `mode`, `query`, `op` and `expected`. Operators are `eq`, `gte` and `lte`. Modes are `at` (requires `tick`), `always` (every tick through the deadline) and `eventually` (must become true before timeout). Optional `fromTick` delays a check. A completed eventual check stays complete; always checks continue throughout the window. Tests remain running until their deadline so future assertions and invariants are not skipped.

Queries:

| Type | Parameters | Result |
| --- | --- | --- |
| `property` | `id`, `field` | `x`, `y`, `hp`, `maxHp` (furniture), `floor`, `alive`, `latched`, or `absAngle` (radians) |
| `count` | `kind`: `npc` or `zombie` | Living, active population |
| `region` | `kind`, `floor`, `x1`, `y1`, `x2`, `y2` | Living population inside the rectangle |
| `separation` | At least two distinct entity `ids` | Smallest same-floor center-to-center distance |
| `event` | `event` type | Number of matching game events |
| `soundConnected` | `floor`, points `a` and `b` | Whether an open acoustic path exists |

Fixtures are validated data, not executable scripts. Extend the typed schema and runner for new supported actions or queries, with a failing-case regression, rather than evaluating imported code. Custom TypeScript tests can also instantiate `TestRunner` directly and inspect the resulting synthetic world.
