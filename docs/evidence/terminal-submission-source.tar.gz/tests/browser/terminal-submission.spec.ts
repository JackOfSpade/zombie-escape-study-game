import { expect, test, type Page } from "@playwright/test";
async function openFixture(page: Page, mode: "solo" | "shared") {
  await page.goto("/");
  await page.getByRole("button", { name: "Enter the building" }).click();
  await page.evaluate(async (mode) => {
    const root = "/src/";
    const { ensureProblem } = await import(/* @vite-ignore */ root + "ai.ts");
    const r = await (await fetch("/curriculum.json")).json();
    const g = (window as any).__deadAir.game,
      st = g.floors[0].stations[0],
      e = g.encounters[st.encounter];
    for (const a of g.survivors.slice(1)) a.escaped = true;
    g.zombies = [];
    Object.assign(g.survivors[0], { x: st.x, y: st.y });
    await ensureProblem(g, e, r);
    e.mode = mode;
    if (mode === "solo") e.owner = "human";
    e.problem.title = "Synthetic answer review";
    e.problem.prompt =
      "Explain a fictional sensor's behavior and one boundary worth checking.";
  }, mode);
  await page.locator("#world").focus();
  await page.keyboard.press("e");
  await expect(page.locator("#workspace")).toBeVisible();
}
test("solo answer panel: offline is not rejection; JSON review is pending, rejected or accepted; tutor sees unsent draft", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  let connected = false;
  let completeCalls = 0;
  let release!: () => Promise<void>;
  const requests: any[] = [];
  await page.route("**/api/status", (route) =>
    route.fulfill({
      json: {
        mode: connected ? "chatgpt-handoff" : "development",
        label: "Synthetic browser transport",
        detail: "No external AI",
        capabilities: connected ? ["complete", "tutor"] : [],
      },
    }),
  );
  await page.route("**/api/bridge", async (route) => {
    const request = route.request().postDataJSON();
    requests.push(request);
    if (request.operation === "tutor") {
      await route.fulfill({
        json: { text: "Which assumption in your draft needs checking?" },
      });
      return;
    }
    expect(request.operation).toBe("complete");
    completeCalls++;
    if (completeCalls === 1) {
      await new Promise<void>(
        (resolve) =>
          (release = async () => {
            await route.fulfill({
              json: {
                complete: false,
                feedback:
                  "Synthetic explanation intentionally outside the verdict panel",
                qualified: [],
              },
            });
            resolve();
          }),
      );
    } else
      await route.fulfill({
        json: {
          complete: true,
          feedback: "Synthetic acceptance only",
          qualified: ["human"],
        },
      });
  });
  await openFixture(page, "solo");
  await expect(page.locator("#conversation-title")).toHaveText("Terminal AI");
  await expect(page.locator("[data-tab]")).toHaveCount(0);
  await expect(page.locator("#workspace")).toHaveValue("");
  await page.locator("#workspace").fill("First synthetic answer");
  await page.locator("#submit").click();
  await expect(page.locator("#submission-status")).toHaveText(
    "Unable to check",
  );
  expect(completeCalls).toBe(0);
  await page.locator("#chat-input").fill("Can you read this answer?");
  await page.locator("#chat-form button").click();
  await expect(page.locator("#tutor-request-status")).toContainText(
    "Connect ChatGPT",
  );
  connected = true;
  await page.evaluate(async () => {
    const root = "/src/";
    const { checkBridge } = await import(/* @vite-ignore */ root + "ai.ts");
    await checkBridge();
  });
  await page.locator("#workspace").fill("Later unsent synthetic answer");
  await page.locator("#chat-input").fill("Help with this later draft");
  await page.locator("#chat-form button").click();
  await expect(page.locator("#messages")).toContainText("Which assumption");
  const tutor = requests.find((r) => r.operation === "tutor");
  expect(tutor.payload.workspace).toBe("Later unsent synthetic answer");
  expect(
    await page.evaluate(
      () =>
        (window as any).__deadAir.game.encounters["f0-room0"].submissions
          .length,
    ),
  ).toBe(1);
  await page.locator("#retry-submission").click();
  await expect(page.locator("#submission-status")).toHaveText(
    "Checking answer…",
  );
  expect(
    requests.find((r) => r.operation === "complete").payload.submission.content,
  ).toBe("First synthetic answer");
  await release();
  await expect(page.locator("#submission-status")).toHaveText("Not accepted");
  await expect(page.locator(".answer-panel")).not.toContainText(
    "Synthetic explanation intentionally",
  );
  await expect(page.locator("#workspace")).toHaveValue(
    "Later unsent synthetic answer",
  );
  await page.screenshot({ path: "test-results/terminal-answer-desktop.png" });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({
    path: "test-results/terminal-answer-mobile.png",
    fullPage: true,
  });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page.locator("#submit").click();
  await expect(page.locator("#submission-status")).toHaveText("Accepted");
  await expect(page.locator("#workspace")).toHaveAttribute("readonly", "");
  expect(completeCalls).toBe(2);
  expect(errors).toEqual([]);
});
test("shared terminal presents only group chat and supplies its current draft without private tutor history", async ({
  page,
}) => {
  let group: any;
  await page.route("**/api/status", (route) =>
    route.fulfill({
      json: {
        mode: "chatgpt-handoff",
        label: "Synthetic browser transport",
        detail: "No external AI",
        capabilities: ["group"],
      },
    }),
  );
  await page.route("**/api/bridge", async (route) => {
    const r = route.request().postDataJSON();
    expect(r.operation).toBe("group");
    group = r.payload;
    await route.fulfill({
      json: {
        requestId: group.requestId,
        sourceRevision: group.sourceRevision,
        messages: [
          {
            author: group.speakers[0].id,
            kind: "question",
            text: "What changes in the current draft?",
            refs: [],
          },
        ],
      },
    });
  });
  await openFixture(page, "shared");
  await expect(page.locator("#conversation-title")).toHaveText("Group chat");
  await expect(page.locator("[data-tab]")).toHaveCount(0);
  await page.locator("#workspace").fill("Shared synthetic draft");
  await page.evaluate(() => {
    const g = (window as any).__deadAir.game,
      e = g.encounters["f0-room0"],
      a = g.survivors[1];
    e.tutor.push({
      id: "private",
      author: "Terminal AI",
      kind: "tutor",
      text: "PRIVATE_SENTINEL",
      seq: ++g.seq,
      worldTime: g.time,
      provenance: "chatgpt-handoff",
    });
    Object.assign(a, {
      escaped: false,
      floor: 0,
      intent: e.id,
      thought: 100,
      x: g.survivors[0].x + 1,
      y: g.survivors[0].y,
      activity: "working",
    });
  });
  await page.locator("#chat-input").fill("What assumption should we check?");
  await page.locator("#chat-form button").click();
  await expect(page.locator("#messages")).toContainText(
    "What changes in the current draft?",
  );
  await expect(page.locator("#messages")).not.toContainText("PRIVATE_SENTINEL");
  expect(group.workspace).toBe("Shared synthetic draft");
  expect(JSON.stringify(group)).not.toContain("PRIVATE_SENTINEL");
  await expect(page.locator("#submission-status")).toHaveText("Not submitted");
});
