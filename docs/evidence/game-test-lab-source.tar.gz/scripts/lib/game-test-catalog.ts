import { existsSync, readFileSync, readdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { PRESETS } from "../../src/gametest/presets";
import { parseScenario } from "../../src/gametest/schema";
/** Checked-in JSON regressions join both the CLI and normal npm test suite. */
export function loadGameTests() {
  const root = fileURLToPath(
    new URL("../../tests/fixtures/gametest/", import.meta.url),
  );
  const files = existsSync(root)
    ? readdirSync(root)
        .filter((name) => name.endsWith(".json"))
        .sort()
    : [];
  if (files.length > 128) throw Error("Too many checked-in GameTest fixtures.");
  const scenarios = [
    ...PRESETS.map((s) => structuredClone(s)),
    ...files.map((name) => {
      try {
        return parseScenario(readFileSync(`${root}/${name}`, "utf8"));
      } catch (error) {
        throw Error(`Invalid GameTest fixture ${name}: ${error}`);
      }
    }),
  ];
  const ids = new Set<string>();
  for (const s of scenarios) {
    if (ids.has(s.id)) throw Error(`Duplicate GameTest ID: ${s.id}`);
    ids.add(s.id);
  }
  return scenarios;
}
