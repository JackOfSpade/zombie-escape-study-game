import { readFileSync, writeFileSync } from "node:fs";
import { loadGameTests } from "./lib/game-test-catalog";
import { TestRunner } from "../src/gametest/runner";
import { parseScenario } from "../src/gametest/schema";
import type { Roadmap } from "../src/model";
const args = process.argv.slice(2);
function option(name: string) {
  const index = args.indexOf(name);
  if (index < 0) return;
  const value = args[index + 1];
  if (!value || value.startsWith("--")) throw Error(`${name} needs a value`);
  return value;
}
try {
  for (let i = 0; i < args.length; i++) {
    if (["--list", "--help"].includes(args[i])) continue;
    if (["--scenario", "--filter", "--json"].includes(args[i])) {
      option(args[i]);
      i++;
      continue;
    }
    throw Error(`Unknown option: ${args[i]}`);
  }
  if (args.includes("--help"))
    console.log(
      "Usage: npm run test:game -- [--list] [--filter ID] [--scenario setup.json] [--json result.json]",
    );
  else if (args.includes("--list"))
    console.log(
      loadGameTests()
        .map((s) => `${s.id}: ${s.name}`)
        .join("\n"),
    );
  else {
    const input = option("--scenario"),
      filter = option("--filter"),
      output = option("--json");
    const scenarios = input
      ? [parseScenario(readFileSync(input, "utf8"))]
      : loadGameTests().filter((s) => !filter || s.id.includes(filter));
    if (!scenarios.length) throw Error("No matching scenarios.");
    const roadmap = JSON.parse(
      readFileSync(
        new URL("../public/curriculum.json", import.meta.url),
        "utf8",
      ),
    ) as Roadmap;
    const results = scenarios.map((s) => new TestRunner(s, roadmap).run());
    if (output)
      writeFileSync(
        output,
        JSON.stringify({ version: 1, results }, null, 2) + "\n",
      );
    for (const r of results) {
      console.log(`${r.status.toUpperCase()} ${r.id} (${r.tick} ticks)`);
      if (r.error) console.log(`  ${r.error}`);
      for (const c of r.checks.filter((c) => c.status !== "passed"))
        console.log(`  ${c.message}`);
    }
    if (results.some((r) => r.status !== "passed")) process.exitCode = 1;
  }
} catch (error) {
  console.error(String(error));
  process.exitCode = 1;
}
