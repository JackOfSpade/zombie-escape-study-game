import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { parallelPreparation } from "../scripts/lib/parallel-preparation";
const roadmap = JSON.parse(readFileSync("public/curriculum.json", "utf8"));
for (const seed of [0, 1, 2])
  test(`independent NPC barricade jobs on generated floors finish sooner in parallel without bonus durability (seed ${seed})`, () => {
    const serial = parallelPreparation(roadmap, seed, false);
    const parallel = parallelPreparation(roadmap, seed, true);
    assert.ok(parallel.seconds < serial.seconds * 0.7);
    assert.ok(
      parallel.overlapFrames > 300,
      "both objects really move in the same simulation frames",
    );
    assert.equal(serial.overlapFrames, 0);
    assert.equal(parallel.stepSeconds, 1 / 30);
    for (const [i, job] of parallel.jobs.entries()) {
      assert.deepEqual(job.final, serial.jobs[i].final);
      assert.equal(job.final.hp, job.initial.hp);
      assert.ok(job.movingFrames > 100);
    }
    assert.ok(
      parallel.jobs.some((j) => j.credited.length > 0),
      "useful shared defense qualifies without any attackers",
    );
    assert.ok(parallel.defenseEvents.length > 0);
    assert.equal(parallel.humanEvidence, 0);
    assert.equal(parallel.humanVisits, 0);
  });
