import { executeCode } from "./code-runner.mjs";

export async function executionRoute(req, res) {
  if (
    req.method !== "POST" ||
    !req.headers["content-type"]?.startsWith("application/json")
  ) {
    res.writeHead(400);
    res.end(JSON.stringify({ error: "POST application/json required" }));
    return;
  }
  try {
    const chunks = [];
    let size = 0;
    for await (const chunk of req) {
      size += chunk.length;
      if (size > 131072) throw Error("Execution request too large");
      chunks.push(chunk);
    }
    const result = await executeCode(
      JSON.parse(Buffer.concat(chunks).toString("utf8")),
    );
    res.writeHead(result.status === "unavailable" ? 503 : 200);
    res.end(JSON.stringify(result));
  } catch (error) {
    const message = String(error);
    res.writeHead(message.includes("Runner busy") ? 409 : 400);
    res.end(JSON.stringify({ error: message }));
  }
}
