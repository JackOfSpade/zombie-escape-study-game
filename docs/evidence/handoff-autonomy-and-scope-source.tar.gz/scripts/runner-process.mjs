import { spawn } from "node:child_process";

export const maxOutput = 65536;
export function boundedText(value, budget) {
  let output = "",
    used = 0;
  for (const character of value) {
    const bytes = Buffer.byteLength(character);
    if (used + bytes > budget) break;
    output += character;
    used += bytes;
  }
  return output;
}
export function docker(
  args,
  input = "",
  timeout = 5000,
  onLimit,
  outputLimit = maxOutput,
) {
  return new Promise((resolve) => {
    const child = spawn("docker", args, { stdio: ["pipe", "pipe", "pipe"] });
    let stdout = "",
      stderr = "",
      stderrPrefix = "",
      size = 0,
      reason;
    const stop = (why) => {
      if (reason) return;
      reason = why;
      onLimit?.();
      child.kill("SIGKILL");
    };
    const timer = setTimeout(() => stop("timeout"), timeout);
    const capture = (stream) => (chunk) => {
      if (stream === "err" && stderrPrefix.length < 1024)
        stderrPrefix += chunk
          .subarray(0, 1024 - stderrPrefix.length)
          .toString("utf8");
      const remaining = Math.max(0, outputLimit - size);
      const value = chunk.subarray(0, remaining).toString("utf8");
      if (stream === "out") stdout += value;
      else stderr += value;
      size += chunk.length;
      if (size > outputLimit) stop("output-limit");
    };
    child.stdout.on("data", capture("out"));
    child.stderr.on("data", capture("err"));
    child.stdin.on("error", () => {});
    child.on("error", () => {
      reason = "unavailable";
    });
    child.on("close", (exitCode) => {
      clearTimeout(timer);
      stdout = boundedText(stdout, outputLimit);
      stderr = boundedText(stderr, outputLimit - Buffer.byteLength(stdout));
      resolve({ stdout, stderr, stderrPrefix, exitCode, reason });
    });
    child.stdin.end(input);
  });
}
