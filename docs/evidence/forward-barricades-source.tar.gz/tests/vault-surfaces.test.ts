import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { TestRunner } from "../src/gametest/runner";
import { emptyScenario } from "../src/gametest/schema";
import { type Roadmap, FURNITURE, type FurnitureKind } from "../src/model";
import { vault } from "../src/engine";
const roadmap: Roadmap = JSON.parse(
  readFileSync("public/curriculum.json", "utf8"),
);
for (const kind of [
  "chair",
  "desk",
  "sofa",
  "fridge",
  "shelf",
] as FurnitureKind[])
  for (const angle of [0, 45, 90])
    test(`Space crosses ${kind} at ${angle} degrees using actual body contacts`, () => {
      const s = emptyScenario(),
        spec = FURNITURE[kind],
        r = (angle * Math.PI) / 180;
      s.maxTicks = 60;
      s.entities = [
        {
          id: "human",
          kind: "player",
          x: 12 - Math.cos(r) * (spec.w / 2 + 0.5),
          y: 12 - Math.sin(r) * (spec.w / 2 + 0.5),
          heading: { x: Math.cos(r), y: Math.sin(r) },
        },
        { id: "prop", kind, x: 12, y: 12, angle },
      ];
      const runner = new TestRunner(s, roadmap),
        g = runner.game,
        a = g.survivors[0];
      assert.equal(vault(g, a), true);
      runner.run();
      assert.equal(a.vault, undefined);
      assert.ok(
        (a.x - 12) * Math.cos(r) + (a.y - 12) * Math.sin(r) > spec.w / 2 + 0.4,
      );
      assert.equal(g.floors[0].furniture[0].hp, spec.hp);
    });
test("vaults reject real walls, closed doors and occupied landings even across a furniture cluster", () => {
  for (const obstacle of ["wall", "door", "npc"]) {
    const s = emptyScenario();
    s.entities = [
      { id: "human", kind: "player", x: 9, y: 12.5, heading: { x: 1, y: 0 } },
      { id: "prop", kind: "desk", x: 10.5, y: 12.5 },
    ];
    const runner = new TestRunner(s, roadmap),
      g = runner.game;
    if (obstacle === "wall") g.floors[0].tiles[12][11] = 1;
    if (obstacle === "door")
      g.floors[0].furniture.push({
        ...g.floors[0].furniture[0],
        id: "door",
        kind: "door",
        x: 11.5,
        w: 0.12,
        h: 3,
        open: false,
      });
    if (obstacle === "npc")
      g.survivors.push({ ...g.survivors[0], id: "blocking-npc", x: 12.15 });
    assert.equal(vault(g, g.survivors[0]), false, obstacle);
  }
});
