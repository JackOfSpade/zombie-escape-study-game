import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createGame } from "../src/world";
import { step, toggleGrip, dragFurniture, vault, rotate } from "../src/engine";
import { canPlace, inFurniture, solid } from "../src/spatial";
import { survivorPath, walkSegment } from "../src/navigation";
import { localPoint, worldPoint } from "../src/furniture-geometry";
import { RunLogs, LOG_LIMITS } from "../src/run-logs";
import type { Roadmap } from "../src/model";
const roadmap: Roadmap = JSON.parse(
  readFileSync("public/curriculum.json", "utf8"),
);
function scene() {
  const g = createGame(11, roadmap),
    f = g.floors[0],
    a = g.survivors[0],
    o = f.furniture.find((o) => o.kind === "sofa")!;
  g.status = "playing";
  g.survivors = [a];
  g.zombies = [];
  g.nextSpawn = 1e9;
  g.surge.anchor = 1e9;
  f.tiles = Array.from({ length: 34 }, () => Array(44).fill(0));
  f.stations = [];
  f.furniture = [o];
  Object.assign(o, { x: 12, y: 12, w: 3.8, h: 1.2, turning: 0, angle: 0 });
  Object.assign(a, { x: 9.55, y: 12 });
  return { g, f, a, o };
}
test("off-center E grip persists without holding a key and pivots the real sofa; E releases", () => {
  const { g, f, a, o } = scene();
  assert.ok(toggleGrip(g, a));
  const before = { ...o };
  for (let i = 0; i < 30; i++) step(g, 1 / 30, { x: 0, y: -1, grab: false });
  assert.equal(a.grip?.object, o.id);
  assert.ok(Math.abs(o.angle!) > 0.05);
  assert.ok(o.y < before.y);
  assert.ok(canPlace(f, o, o));
  assert.ok(!inFurniture(a, o, 0.22));
  const local = localPoint(a, o);
  assert.ok(
    Math.hypot(local.x - a.grip!.local.x, local.y - a.grip!.local.y) < 1e-6,
  );
  assert.ok(toggleGrip(g, a));
  assert.equal(a.grip, undefined);
  const pose = [o.x, o.y, o.angle];
  step(g, 0.1, { x: -1, y: 0, grab: false });
  assert.ok(
    Math.hypot(o.x - pose[0]!, o.y - pose[1]!) < 0.3,
    "release preserves bounded momentum",
  );
  for (let i = 0; i < 90; i++) step(g, 1 / 30);
  assert.ok(
    Math.hypot(o.physics!.x, o.physics!.y) < 0.01,
    "floor friction brings released furniture to rest",
  );
});
test("drag sweeps reject walls and bodies rather than clipping rotated corners", () => {
  const { g, f, a, o } = scene();
  assert.ok(toggleGrip(g, a));
  f.tiles[11][10] = 1;
  const pose = JSON.stringify(o);
  assert.equal(dragFurniture(g, a, 0, -1, 0.1), false);
  assert.equal(JSON.stringify(o), pose);
  f.tiles[11][10] = 0;
  const npc = { ...a, id: "blocking-body", x: 12, y: 11.15 };
  g.survivors.push(npc);
  for (let i = 0; i < 100; i++) dragFurniture(g, a, 0, -1, 1 / 30);
  assert.ok(!inFurniture(npc, o, 0.23));
  assert.ok(!solid(f, a));
});
test("Esc pause freezes the entire engine including timers, paths and damage", () => {
  const { g } = scene();
  g.paused = true;
  const before = JSON.stringify(g);
  step(g, 0.1, { x: 1, y: 1, grab: true });
  assert.equal(JSON.stringify(g), before);
});
test("rotated furniture uses matching collision, swept walk and cross-face vault geometry", () => {
  const { g, f, a, o } = scene();
  o.angle = Math.PI / 4;
  Object.assign(a, worldPoint({ x: 0, y: -o.h / 2 - 0.55 }, o));
  a.heading = worldPoint({ x: 0, y: 1 }, { x: 0, y: 0, angle: o.angle });
  const target = worldPoint({ x: 0, y: o.h / 2 + 0.55 }, o);
  assert.equal(walkSegment(f, a, target), false);
  assert.ok(survivorPath(f, a, target).length);
  assert.ok(vault(g, a, o.id));
  assert.ok(
    Math.hypot(a.vault!.to.x - target.x, a.vault!.to.y - target.y) < 1e-6,
  );
  for (let i = 0; i < 50; i++) step(g, 1 / 30);
  assert.ok(!solid(f, a));
});
test("last-three-game logs survive reload, prune old games and bound each game without learning content", async () => {
  let stored: string | null = null;
  const storage = {
    read: async () => stored,
    write: async (value: string) => {
      stored = value;
    },
  };
  const logs = new RunLogs(storage),
    { g } = scene();
  const study = JSON.stringify(g.study);
  for (let i = 0; i < 5; i++) {
    g.id = `run-${i}`;
    logs.record(g, "start");
    logs.capture(g, true);
  }
  for (let i = 0; i < 700; i++)
    logs.record(g, "bounded", { payload: "x".repeat(2000) });
  await logs.flush();
  const restored = new RunLogs(storage);
  await restored.load();
  assert.deepEqual(
    restored.runs.map((r) => r.id),
    ["run-2", "run-3", "run-4"],
  );
  for (const run of restored.runs) {
    assert.ok(run.entries.length <= LOG_LIMITS.entries);
    assert.ok(JSON.stringify(run).length <= LOG_LIMITS.bytesPerGame);
  }
  assert.equal(JSON.stringify(g.study), study);
  assert.ok(!stored!.includes('"study"'));
  assert.ok(!stored!.includes('"history"'));
});

test("rotated corner placement distinguishes actual wall contact from empty bounding-box corners", () => {
  const { f, o } = scene();
  o.angle = Math.PI / 4;
  f.tiles[13][10] = 1;
  assert.ok(
    canPlace(f, o, o),
    "empty lower-left bounding-box corner stays clear",
  );
  f.tiles[13][13] = 1;
  assert.equal(
    canPlace(f, o, o),
    false,
    "actual far corner cannot rotate through wall",
  );
});
test("swept dragging advances toward a wall then stops without embedding the held end or far corner", () => {
  const { g, f, a, o } = scene();
  f.tiles[10][10] = 1;
  assert.ok(canPlace(f, o, o));
  assert.ok(toggleGrip(g, a));
  const before = { x: o.x, y: o.y };
  let moved = false;
  for (let i = 0; i < 300; i++) {
    moved = dragFurniture(g, a, 0, -1, 1 / 30) || moved;
    assert.ok(canPlace(f, o, o));
    assert.ok(!solid(f, a));
  }
  assert.ok(moved);
  assert.ok(Math.hypot(o.x - before.x, o.y - before.y) > 0.01);
  assert.equal(
    dragFurniture(g, a, 0, -1, 1 / 30),
    false,
    "blocked pose holds instead of tunneling",
  );
});

test("NPC quarter-turns reject a survivor inside the rotated target footprint outside its old axis-aligned bounds", () => {
  const { g, f, a, o } = scene();
  o.angle = Math.PI / 4;
  Object.assign(a, worldPoint({ x: -o.w / 2 - 0.55, y: 0 }, o));
  const bystander = {
    ...a,
    id: "bystander",
    ...worldPoint({ x: 0, y: 1.6 }, o),
  };
  g.survivors.push(bystander);
  assert.ok(
    !solid(f, bystander),
    "bystander starts outside existing furniture",
  );
  assert.ok(inFurniture(bystander, { ...o, w: o.h, h: o.w }, 0.25));
  const pose = [o.x, o.y, o.w, o.h, o.angle];
  assert.equal(rotate(g, a), false);
  assert.deepEqual([o.x, o.y, o.w, o.h, o.angle], pose);
  g.survivors.pop();
  assert.equal(
    rotate(g, a),
    true,
    "turn remains available after the actual obstruction clears",
  );
});

test("a run ending between periodic snapshots saves its final state without waiting for another simulation tick", async () => {
  let stored: string | null = null;
  const logs = new RunLogs({
      read: async () => stored,
      write: async (value) => {
        stored = value;
      },
    }),
    { g } = scene();
  logs.capture(g);
  g.time = 0.1;
  g.status = "dead";
  g.survivors[0].alive = false;
  logs.capture(g);
  await logs.flush();
  const saved = JSON.parse(stored!);
  assert.equal(saved.runs[0].entries.at(-1).data.status, "dead");
  assert.equal(saved.runs[0].entries.at(-1).data.actors[0].alive, false);
});
test("pruned diagnostic tails keep a compact whole-run outcome summary", () => {
  const { g } = scene(),
    logs = new RunLogs({ read: async () => null, write: async () => {} });
  for (let i = 0; i < 450; i++) {
    g.time = i;
    logs.record(g, "snapshot", { position: i });
  }
  g.time = 450;
  g.status = "dead";
  g.stats.deaths = 1;
  logs.capture(g, true);
  const run = logs.runs[0];
  assert.ok(run.entries.length <= LOG_LIMITS.entries);
  assert.equal(run.summary!.duration, 450);
  assert.equal(run.summary!.outcome, "dead");
  assert.equal(run.summary!.deaths, 1);
  assert.ok(run.summary!.snapshots >= 450);
  logs.record(g, "restart");
  assert.equal(run.summary!.outcome, "restarted");
});
