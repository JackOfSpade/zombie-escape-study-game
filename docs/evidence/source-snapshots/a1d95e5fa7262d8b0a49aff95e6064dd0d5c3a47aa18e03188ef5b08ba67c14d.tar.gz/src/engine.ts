import { ZombieIndex } from "./zombie-index";
import { rememberThreats, rememberedThreats } from "./npc-threat-memory";
import { zombieStairArrival } from "./zombie-stairs";
import { beginStairs, advanceStairs, cancelStairs } from "./stair-travel";
import { chooseTaskStation } from "./task-strategy";
import { interruptLearningAttempt } from "./learner";
import { chooseFurnitureYield } from "./furniture-yield";
import {
  doorwayGoal,
  explorationCell,
  rememberPlace,
  observeDoorEntry,
} from "./exploration";
import { EQUIPMENT, itemTargets, itemUseIssue } from "./equipment";
import {
  taskSkill,
  recordNpcWork,
  recordNpcActivity,
  npcReasoningAvailable,
  hasHumanStudyContext,
} from "./npc-cognition";
import { survivorPath, walkSegment } from "./navigation";
import {
  type Game,
  type Actor,
  type Zombie,
  type Point,
  type Furniture,
  type Floor,
  type Encounter,
  CONFIG,
  distance,
  event,
  rand,
} from "./model";
import {
  solid,
  wall,
  move,
  line,
  path,
  inFurniture,
  canPlace,
  soundGain,
} from "./spatial";
import { canSee, sightRadius } from "./visibility";
import { canGrip } from "./handling";
import { furnitureRoute, handlingPositions } from "./fortification";
import {
  chooseRetreat,
  routeContacts,
  unsafeReturn,
} from "./survivor-strategy";
export interface Input {
  x: number;
  y: number;
  grab: boolean;
}
export const human = (g: Game) => g.survivors[0];
export function nearestFurniture(g: Game, a: Actor, grip = false) {
  return g.floors[a.floor].furniture
    .filter(
      (o) =>
        !o.destroyed &&
        o.kind !== "gate" &&
        o.kind !== "door" &&
        (!grip || canGrip(g.floors[a.floor], a, o)),
    )
    .sort((b, c) => distance(a, b) - distance(a, c))[0];
}
export function nearestStation(g: Game, a: Actor) {
  return g.floors[a.floor].stations
    .filter((s) => canReachStation(g, a, s))
    .sort((b, c) => distance(a, b) - distance(a, c))[0];
}
export function canReachStation(
  g: Game,
  a: Actor,
  station: Point,
  range = 1.9,
) {
  return (
    a.alive &&
    !a.escaped &&
    !a.vault &&
    distance(a, station) < range &&
    canSee(g.floors[a.floor], a, station, range)
  );
}
export function nearbyDoor(g: Game, a: Actor) {
  return g.floors[a.floor].furniture
    .filter(
      (o) =>
        o.kind === "door" &&
        !o.destroyed &&
        distance(a, o) < 1.9 &&
        canSee(g.floors[a.floor], a, o, 1.9, o.id),
    )
    .sort((b, c) => distance(a, b) - distance(a, c))[0];
}
export function toggleDoor(g: Game, a: Actor, id: string, open?: boolean) {
  const f = g.floors[a.floor],
    door = f.furniture.find(
      (o) => o.id === id && o.kind === "door" && !o.destroyed,
    );
  if (
    !door ||
    !a.alive ||
    a.escaped ||
    distance(a, door) > 1.9 ||
    !canSee(f, a, door, 1.9, door.id)
  )
    return false;
  const next = open ?? !door.open;
  if (next === !!door.open) return true;
  if (!next) {
    const closed = { ...door, open: false };
    if (
      !canPlace(f, door, door) ||
      g.survivors.some(
        (b) =>
          b.alive &&
          !b.escaped &&
          b.floor === a.floor &&
          inFurniture(b, closed, 0.23),
      ) ||
      g.zombies.some(
        (z) => z.hp > 0 && z.floor === a.floor && inFurniture(z, closed, 0.23),
      )
    )
      return false;
  }
  door.open = next;
  a.noiseUntil = g.time + 1;
  a.noiseLevel = 8;
  event(
    g,
    "door",
    `${a.name} ${next ? "opened" : "closed"} a room door.`,
    a.floor,
    a.id,
  );
  return true;
}
export function claimStation(g: Game, a: Actor, stationId: string) {
  if (a.stairTravel) return false;
  const station = g.floors[a.floor].stations.find((s) => s.id === stationId);
  if (!station || !canReachStation(g, a, station)) return false;
  const e = g.encounters[station.encounter];
  if (e.mode === "solo" && e.owner && e.owner !== a.id) return false;
  if (
    g.survivors.some(
      (b) =>
        b.id !== a.id &&
        b.alive &&
        !b.escaped &&
        b.floor === a.floor &&
        b.station === station.id &&
        distance(b, station) < 1.3,
    )
  )
    return false;
  a.station = station.id;
  a.intent = e.id;
  a.activity = "studying";
  if (a.id === "human" && e.state !== "consumed") e.humanEngaged = true;
  if (e.mode === "solo" && e.state !== "consumed") e.owner ??= a.id;
  return true;
}
export function releaseStation(a: Actor) {
  delete a.station;
}
function death(g: Game, a: Actor) {
  a.alive = false;
  a.hp = 0;
  delete a.stairTravel;
  g.stats.deaths++;
  g.surge.lastDeath = g.time;
  if (g.surge.state === "calm") {
    g.surge.anchor = Math.max(g.time, g.surge.lastEnd);
    g.surge.quietDelay =
      CONFIG.quietMin + rand(g) * (CONFIG.quietMax - CONFIG.quietMin);
  }
  const ev = event(
    g,
    "death",
    `${a.name} was lost on Floor ${a.floor + 1}.`,
    a.floor,
    a.id,
  );
  if (a.intent && g.encounters[a.intent])
    g.encounters[a.intent].history.push({
      seq: ev.seq,
      author: a.id,
      kind: "activity",
      text: ev.text,
      at: g.time,
      revision: g.encounters[a.intent].revision,
    });
  if (a.id === "human") {
    g.status = "dead";
    g.notice =
      "The run ended. Your terminal work and learning evidence are preserved.";
  }
}
export function tickSurge(g: Game) {
  const s = g.surge;
  if (s.state === "calm" && g.time >= s.anchor + s.quietDelay) {
    s.state = "warning";
    s.started = g.time;
    s.duration =
      CONFIG.surgeMin + rand(g) * (CONFIG.surgeMax - CONFIG.surgeMin);
    event(
      g,
      "surge-warning",
      "An escalating pulse rises through the building.",
    );
  } else if (s.state === "warning" && g.time >= s.started + CONFIG.warning) {
    s.state = "active";
    s.started = g.time;
    event(g, "surge-active", "The Surge transformed the horde.");
  } else if (s.state === "active" && g.time >= s.started + s.duration) {
    s.state = "calm";
    s.lastEnd = g.time;
    s.anchor = Math.max(g.time, s.lastDeath);
    s.quietDelay =
      CONFIG.quietMin + rand(g) * (CONFIG.quietMax - CONFIG.quietMin);
    event(g, "surge-end", "The pulse subsides.");
  }
}
export function stairs(g: Game, a: Actor, down = false) {
  return beginStairs(g, a, down);
}
export function board(g: Game, a: Actor) {
  if (
    a.stairTravel ||
    a.floor !== CONFIG.floors ||
    !a.alive ||
    a.escaped ||
    distance(a, { x: 21.5, y: 10.5 }) > 2.8 ||
    g.time >= g.helicopter.until ||
    g.helicopter.passengers.length >= 4
  )
    return false;
  g.helicopter.passengers.push(a.id);
  a.escaped = true;
  delete a.handling;
  delete a.station;
  a.path = [];
  g.stats.rescued++;
  event(
    g,
    "board",
    `${a.name} boarded pickup ${g.helicopter.trip}.`,
    a.floor,
    a.id,
  );
  if (a.id === "human") {
    g.status = "escaped";
    g.notice = "You made it. Your work survives with you.";
  }
  return true;
}
export function vault(g: Game, a: Actor, obstacleId?: string) {
  if (!a.alive || a.escaped || a.vault || a.stairTravel || a.cooldown > 0)
    return false;
  const f = g.floors[a.floor],
    o = obstacleId
      ? f.furniture.find(
          (o) =>
            o.id === obstacleId &&
            !o.destroyed &&
            o.kind !== "door" &&
            o.kind !== "gate",
        )
      : nearestFurniture(g, a);
  if (!o || distance(a, o) > 2.7) return false;
  const d = a.heading;
  const dx = Math.abs(d.x) > Math.abs(d.y),
    dir = dx ? Math.sign(d.x) : Math.sign(d.y);
  if (!dir) return false;
  const to = {
    x: dx ? o.x + dir * (o.w / 2 + 0.55) : a.x,
    y: dx ? a.y : o.y + dir * (o.h / 2 + 0.55),
  };
  const startsBefore = dx ? dir * (a.x - o.x) < 0 : dir * (a.y - o.y) < 0;
  let crosses = false;
  for (let i = 0; i <= 24; i++) {
    const p = {
      x: a.x + ((to.x - a.x) * i) / 24,
      y: a.y + ((to.y - a.y) * i) / 24,
    };
    if (inFurniture(p, o)) crosses = true;
    if (solid(f, p, 0.22, o.id)) return false;
  }
  if (!startsBefore || !crosses) return false;
  if (
    distance(a, to) > 4.7 ||
    solid(f, to) ||
    !line(f, a, to) ||
    g.survivors.some(
      (b) =>
        b.id !== a.id &&
        b.floor === a.floor &&
        b.alive &&
        !b.escaped &&
        distance(b, to) < 0.55,
    ) ||
    g.zombies.some(
      (z) => z.floor === a.floor && z.hp > 0 && distance(z, to) < 0.55,
    )
  )
    return false;
  a.vault = {
    from: { x: a.x, y: a.y },
    to,
    left: o.kind === "chair" ? 0.45 : 1.1,
    duration: o.kind === "chair" ? 0.45 : 1.1,
    obstacle: o.id,
  };
  event(g, "vault", `${a.name} climbed over ${o.kind}.`, a.floor, a.id);
  return true;
}
function advanceVault(a: Actor, dt: number) {
  const v = a.vault!;
  v.left -= dt;
  const p = 1 - Math.max(0, v.left) / v.duration;
  a.x = v.from.x + (v.to.x - v.from.x) * p;
  a.y = v.from.y + (v.to.y - v.from.y) * p;
  if (v.left <= 0) {
    delete a.vault;
    a.path = [];
    a.repath = 0;
    a.cooldown = 0.3;
  }
}
export function rotate(g: Game, a: Actor) {
  const o = nearestFurniture(g, a, true);
  if (!o || !canGrip(g.floors[a.floor], a, o) || o.turning > 0) return false;
  const f = g.floors[a.floor];
  if (
    !canPlace(f, o, o, o.h, o.w) ||
    g.zombies.some(
      (z) =>
        z.hp > 0 &&
        z.floor === a.floor &&
        inFurniture(z, { ...o, w: o.h, h: o.w }, 0.22),
    ) ||
    g.survivors.some(
      (b) =>
        b.floor === a.floor &&
        b.alive &&
        !b.escaped &&
        Math.abs(b.x - o.x) < o.h / 2 + 0.25 &&
        Math.abs(b.y - o.y) < o.w / 2 + 0.25,
    )
  )
    return false;
  o.initial ??= { x: o.x, y: o.y, w: o.w, h: o.h };
  [o.w, o.h] = [o.h, o.w];
  o.rotation = (o.rotation + 1) % 2;
  o.turning = 1.2;
  event(g, "rotate", `${a.name} rotated a ${o.kind}.`, a.floor, a.id);
  defenseCredit(g, a, o);
  return true;
}
function defenseCredit(g: Game, a: Actor, o: Furniture) {
  if (o.credited.length || !o.initial) return;
  if (o.moved < 0.8 && o.w === o.initial.w && o.h === o.initial.h) return;
  const f = g.floors[a.floor];
  for (const d of f.doors) {
    if (distance(d, o) > 8 || !inFurniture({ x: o.x, y: d.y }, o, 0.22))
      continue;
    const left = d.x < 22;
    const station = f.stations.find(
      (s) =>
        (left ? s.x < 17 : s.x > 26) &&
        Math.abs(s.y - d.y) < 9 &&
        g.encounters[s.encounter].mode === "shared" &&
        g.encounters[s.encounter].state !== "consumed",
    );
    if (!station) continue;
    const e = g.encounters[station.encounter];
    // Compare this furniture's added protection with the physical door open.
    // A closed existing door must not hide a useful second defensive layer.
    const geometry = {
      ...f,
      furniture: f.furniture.map((x) =>
        x.kind === "door" && distance(x, d) < 0.1 ? { ...x, open: true } : x,
      ),
    };
    const before = path(
      {
        ...geometry,
        furniture: geometry.furniture.map((x) =>
          x.id === o.id ? { ...x, ...o.initial } : x,
        ),
      },
      { x: 21.5, y: d.y },
      station,
    );
    const after = path(geometry, { x: 21.5, y: d.y }, station);
    if (!before.length || after.length) continue;
    const participants = g.survivors.filter(
      (b) =>
        b.alive &&
        !b.escaped &&
        b.floor === a.floor &&
        (b.id === a.id || b.handling === o.id) &&
        (b.id === a.id || canGrip(f, b, o)),
    );
    for (const participant of participants) {
      if (!e.contributors.includes(participant.id))
        e.contributors.push(participant.id);
      o.credited.push(participant.id);
      const ev = event(
        g,
        "defense",
        `${participant.name} helped seal an approach with a ${o.kind}.`,
        a.floor,
        participant.id,
        e.id,
      );
      e.history.push({
        seq: ev.seq,
        author: participant.id,
        kind: "defense",
        text: ev.text,
        at: g.time,
        revision: e.revision,
        refs: [o.id],
      });
    }
  }
}
export function pushFurniture(
  g: Game,
  a: Actor,
  dx: number,
  dy: number,
  dt: number,
) {
  const f = g.floors[a.floor];
  let o = a.handling
    ? f.furniture.find((x) => x.id === a.handling)
    : nearestFurniture(g, a, true);
  if (!o || !canGrip(f, a, o) || o.turning > 0) {
    delete a.handling;
    return false;
  }
  o.initial ??= { x: o.x, y: o.y, w: o.w, h: o.h };
  a.handling = o.id;
  if (!o.movers.includes(a.id)) o.movers.push(a.id);
  if (g.tick !== undefined && o.lastMoveTick === g.tick) return false;
  const handlers = g.survivors.filter(
    (b) => (b.id === a.id || b.handling === o!.id) && canGrip(f, b, o!),
  );
  const speed = o.speed * (1 + 0.45 * Math.min(handlers.length - 1, 2)),
    n = Math.hypot(dx, dy) || 1,
    p = { x: o.x + (dx / n) * speed * dt, y: o.y + (dy / n) * speed * dt };
  if (!canPlace(f, o, p)) {
    // Forgiving axis alignment still takes handling time and moves the actor.
    // It cannot shrink an object or snap it through a wall/another object.
    const horizontal = Math.abs(dx) >= Math.abs(dy),
      value = horizontal ? o.y : o.x,
      snap = Math.round(value - 0.5) + 0.5,
      delta = snap - value;
    if (Math.abs(delta) > 1e-7 && Math.abs(delta) < 0.18) {
      const aligned = { x: o.x, y: o.y };
      if (horizontal)
        aligned.y += Math.sign(delta) * Math.min(Math.abs(delta), speed * dt);
      else
        aligned.x += Math.sign(delta) * Math.min(Math.abs(delta), speed * dt);
      if (canPlace(f, o, aligned)) Object.assign(p, aligned);
    }
  }
  if (
    canPlace(f, o, p) &&
    !g.survivors.some(
      (b) =>
        b.id !== a.id &&
        b.alive &&
        !b.escaped &&
        b.floor === a.floor &&
        inFurniture(b, { ...o!, ...p }, 0.23) &&
        !handlers.includes(b),
    ) &&
    !g.zombies.some(
      (z) =>
        z.hp > 0 &&
        z.floor === a.floor &&
        inFurniture(z, { ...o!, ...p }, 0.22),
    )
  ) {
    const shift = { x: p.x - o.x, y: p.y - o.y };
    const positions = handlers.map((b) => {
      const next = { x: b.x, y: b.y };
      move(f, next, shift.x, shift.y, o!.id);
      return next;
    });
    if (
      positions.some(
        (next, i) =>
          distance(next, {
            x: handlers[i].x + shift.x,
            y: handlers[i].y + shift.y,
          }) > 1e-6 || inFurniture(next, { ...o!, ...p }, 0.22),
      )
    )
      return false;
    o.x = p.x;
    o.y = p.y;
    o.lastMoveTick = g.tick;
    o.moved += Math.hypot(shift.x, shift.y);
    o.lastBy = a.id;
    a.noiseUntil = g.time + 1;
    a.noiseLevel = 8;
    handlers.forEach((b, i) => {
      Object.assign(b, positions[i]);
      if (!o!.movers.includes(b.id)) o!.movers.push(b.id);
    });
    defenseCredit(g, a, o);
    return true;
  }
  return false;
}
function follow(
  g: Game,
  a: Actor,
  target: Point,
  dt: number,
  allowExit = true,
) {
  const f = g.floors[a.floor];
  if (!a.navTarget || distance(a.navTarget, target) > 0.75) {
    a.navTarget = { ...target };
    a.repath = 0;
    a.path = [];
  }
  a.repath -= dt;
  if (!a.path.length && a.repath <= 0) {
    a.path = survivorPath(f, a, target);
    if (!a.path.length && distance(a, target) > 0.5) {
      // A closed door can sit immediately beside a barricade. Open its visible
      // reachable side first, then replan the vault with that door actually open.
      const doors = f.furniture
        .filter(
          (o) =>
            o.kind === "door" &&
            !o.open &&
            !o.destroyed &&
            canSee(f, a, o, sightRadius(f), o.id),
        )
        .sort((b, c) => distance(a, b) - distance(a, c));
      for (const door of doors) {
        const route = survivorPath(f, a, door);
        if (route.length) {
          a.path = route;
          break;
        }
      }
    }
    a.repath = 0.8 + rand(g) * 0.4;
  }
  let p = a.path[0];
  if (p && distance(a, p) < 0.04) {
    a.path.shift();
    p = a.path[0];
  }
  if (!p) {
    if (
      allowExit &&
      distance(a, target) > 0.5 &&
      roomAt(a) >= 0 &&
      roomAt(a) !== roomAt(target)
    )
      clearExit(g, a, dt, target);
    return;
  }
  const d = distance(a, p),
    k = Math.min(a.speed * dt, d) / (d || 1);
  a.heading = { x: (p.x - a.x) / (d || 1), y: (p.y - a.y) / (d || 1) };
  if (p.action) {
    const obstacle = f.furniture.find(
      (o) => o.id === p.obstacle && !o.destroyed && !o.open,
    );
    if (obstacle) {
      if (p.action === "door") {
        if (!toggleDoor(g, a, obstacle.id, true)) {
          a.path = [];
          a.repath = 0.5;
          return;
        }
      } else {
        // A temporary recovery is not an invalid route. Keep the exact legal
        // action ready so expiry does not add a second path-retry delay.
        if (a.cooldown > 0) return;
        if (!vault(g, a, obstacle.id)) {
          a.path = [];
          a.repath = 0.5;
        }
        return;
      }
    }
  }
  const before = { x: a.x, y: a.y };
  move(f, a, (p.x - a.x) * k, (p.y - a.y) * k);
  if (distance(before, a) > 0.001) {
    a.noiseUntil = g.time + 0.4;
    a.noiseLevel = a.activity === "fleeing" ? 6 : 3;
    a.blockedTime = 0;
  } else a.blockedTime = (a.blockedTime ?? 0) + dt;
  if (a.blockedTime > 0.5) {
    a.path = [];
    a.repath = 0;
    a.blockedTime = 0;
  }
}

function yieldFurniture(g: Game, a: Actor, dt: number) {
  if (
    a.furnitureYield &&
    (a.furnitureYield.floor !== a.floor ||
      g.time >= a.furnitureYield.until ||
      distance(a, a.furnitureYield.target) < 0.25 ||
      a.defensePlan)
  )
    delete a.furnitureYield;
  if (!a.furnitureYield) {
    const target = chooseFurnitureYield(g, a);
    if (target)
      a.furnitureYield = { floor: a.floor, target, until: g.time + 4 };
  }
  if (!a.furnitureYield) return false;
  a.activity = "waiting";
  delete a.station;
  follow(g, a, a.furnitureYield.target, dt, false);
  return true;
}
function fortify(g: Game, a: Actor, e: Encounter, dt: number) {
  const f = g.floors[a.floor],
    room = Number(/room(\d+)/.exec(e.id)?.[1]),
    outer = f.doors[room];
  if (!outer) return false;
  const metadata = f.rooms?.find((r) => r.index === room),
    mouth = metadata?.innerMouth ?? outer;
  const target = { x: mouth.x + (mouth.x < 22 ? -1.1 : 1.1), y: mouth.y };
  if (a.defensePlan?.encounter !== e.id) delete a.defensePlan;
  if (!a.defensePlan) {
    if (g.time < (a.defenseRetryAt ?? 0)) return false;
    const candidates = f.furniture
      .filter(
        (o) =>
          o.id.startsWith(`f${a.floor}-room${room}-`) &&
          o.kind === "shelf" &&
          !o.destroyed &&
          !o.credited.length &&
          o.h > o.w &&
          canSee(f, a, o, sightRadius(f), o.id) &&
          distance(o, target) > 0.05,
      )
      .sort((b, c) => distance(b, target) - distance(c, target));
    for (const object of candidates) {
      const route = furnitureRoute(f, object, target, a);
      if (route.length) {
        a.defensePlan = {
          encounter: e.id,
          object: object.id,
          target,
          route,
          idle: 0,
        };
        break;
      }
    }
    if (!a.defensePlan) {
      a.defenseRetryAt = g.time + 12;
      return false;
    }
  }
  return followFurniturePlan(g, a, dt);
}
function followFurniturePlan(g: Game, a: Actor, dt: number) {
  const f = g.floors[a.floor],
    plan = a.defensePlan!;
  const object = f.furniture.find((o) => o.id === plan.object);
  if (!object || object.destroyed) {
    delete a.defensePlan;
    return false;
  }
  while (plan.route.length && distance(object, plan.route[0]) < 0.025)
    plan.route.shift();
  const next = plan.route[0];
  if (!next) {
    delete a.defensePlan;
    a.defenseRetryAt = g.time + 12;
    return false;
  }
  const before = { x: a.x, y: a.y },
    pose = { x: object.x, y: object.y };
  const approach = handlingPositions(f, object, next, a).find(
    (p) =>
      !g.survivors.some(
        (b) =>
          b !== a &&
          b.alive &&
          !b.escaped &&
          b.floor === a.floor &&
          distance(p, b) < 0.48,
      ),
  );
  if (approach) {
    if (distance(a, approach) > 0.18) follow(g, a, approach, dt, false);
    else {
      a.handling = object.id;
      const horizontal =
        Math.abs(next.x - object.x) >= Math.abs(next.y - object.y);
      const delta = horizontal ? next.x - object.x : next.y - object.y;
      pushFurniture(
        g,
        a,
        horizontal ? Math.sign(delta) : 0,
        horizontal ? 0 : Math.sign(delta),
        Math.min(dt, Math.abs(delta) / (object.speed * 1.9)),
      );
    }
  }
  plan.idle =
    object.lastMoveTick === g.tick ||
    distance(before, a) + distance(pose, object) > 0.0001
      ? 0
      : plan.idle + dt;
  if (plan.idle > 6) {
    delete a.defensePlan;
    a.defenseRetryAt = g.time + 12;
    return false;
  }
  return true;
}

function roomAt(p: Point) {
  return p.x < 17 ? (p.y < 15 ? 0 : 2) : p.x > 27 ? (p.y < 15 ? 1 : 3) : -1;
}
function clearExit(g: Game, a: Actor, dt: number, target?: Point) {
  const f = g.floors[a.floor];
  if (a.path.length && a.defensePlan?.encounter !== "egress") return false;
  const destination = target ?? a.defensePlan?.exit ?? f.stairs;
  if (survivorPath(f, a, destination).length) {
    if (a.defensePlan?.encounter === "egress") delete a.defensePlan;
    return false;
  }
  if (a.defensePlan?.encounter !== "egress") {
    delete a.defensePlan;
    if (a.x >= 17 && a.x <= 27) return false;
    const side = a.x < 17 ? 0 : 1,
      room = (a.y < 15 ? 0 : 2) + side,
      door = f.doors[room];
    if (!door) return false;
    const object = f.furniture.find(
      (o) =>
        o.id.startsWith(`f${a.floor}-room${room}-`) &&
        !o.destroyed &&
        o.speed > 0 &&
        o.h > o.w &&
        distance(o, door) < 2.1,
    );
    if (!object) return false;
    const target = { x: object.x + (side === 0 ? -0.9 : 0.9), y: object.y };
    const route = furnitureRoute(f, object, target, a);
    if (!route.length) return false;
    a.defensePlan = {
      encounter: "egress",
      object: object.id,
      target,
      route,
      idle: 0,
      exit: destination,
    };
  }
  return followFurniturePlan(g, a, dt);
}
function npc(g: Game, a: Actor, dt: number) {
  // Taking an already available escape wins over retreating from a nearby
  // threat. Boarding still uses the same physical range and atomic seat check.
  if (a.floor === CONFIG.floors && board(g, a)) {
    a.activity = "climbing";
    return;
  }
  const f = g.floors[a.floor];
  observeDoorEntry(f, a);
  const enemies = g.zombies.filter(
    (z) =>
      z.floor === a.floor &&
      z.hp > 0 &&
      canSee(f, a, z, Math.min(9, sightRadius(f))),
  );
  let near: Zombie | undefined = enemies.sort(
    (b, c) => distance(a, b) - distance(a, c),
  )[0];
  for (const st of f.stations)
    if (canSee(f, a, st) && !a.seen.includes(st.id)) a.seen.push(st.id);
  for (const station of f.stations) {
    const cache = g.encounters[station.encounter];
    if (
      cache.state === "consumed" &&
      cache.reward === "loot" &&
      cache.contributors.includes(a.id) &&
      distance(a, station) < 1.9
    ) {
      const item = cache.loot.find(
        (i) =>
          a.inventory.reduce((n, j) => n + j.weight, 0) + i.weight <=
          CONFIG.capacity,
      );
      if (item) takeLoot(g, a, cache.id, item.id);
    }
  }
  if (a.hp < 65) {
    const med = a.inventory.find((i) => i.kind === "medkit");
    if (med) useItem(g, a, med.id);
  }
  if (near && distance(a, near) < 4) {
    const defense = a.inventory.find(
      (i) =>
        i.kind === "weapon" ||
        i.kind === "repulsor" ||
        (i.kind === "bubble" && a.hp < 60),
    );
    if (defense) useItem(g, a, defense.id);
  }
  if (
    f.dark > 0.8 &&
    !g.effects.some(
      (e) =>
        e.kind === "flare" &&
        e.until > g.time &&
        e.floor === a.floor &&
        canSee(f, e, a, Math.min(e.radius, 5)),
    )
  ) {
    const light = a.inventory.find(
      (i) => i.kind === "flare" || i.kind === "battery",
    );
    if (light) useItem(g, a, light.id);
  }
  near = enemies.find((z) => z.hp > 0);
  rememberThreats(g, a, enemies);
  const liveThreats = enemies.filter((z) => z.hp > 0),
    liveIds = new Set(liveThreats.map((z) => z.id));
  const planningThreats = [
    ...liveThreats,
    ...rememberedThreats(g, a).filter((p) => !liveIds.has(p.id)),
  ];
  let attention = 0.4;
  delete a.handling;
  const pickup =
    a.floor === CONFIG.floors &&
    g.time < g.helicopter.until &&
    g.helicopter.passengers.length < 4;
  if (pickup && a.pickupTrip !== g.helicopter.trip) {
    a.pickupTrip = g.helicopter.trip;
    delete a.fleeTarget;
    a.fleeUntil = 0;
  }
  const reactionDistance = 3 + (1 - a.risk) * 2 + (a.hp < 45 ? 0.8 : 0);
  let immediateThreat =
    near && near.hp > 0 && distance(a, near) < reactionDistance;
  const committedRetreat =
    a.activity === "fleeing" &&
    a.fleeTarget &&
    a.fleeFloor === a.floor &&
    g.time < (a.fleeUntil ?? 0) &&
    distance(a, a.fleeTarget) > 0.8;
  if (
    !immediateThreat &&
    !committedRetreat &&
    a.activity === "fleeing" &&
    planningThreats.length > 0 &&
    unsafeReturn(g, a, planningThreats)
  )
    immediateThreat = true;
  if (
    !immediateThreat &&
    !committedRetreat &&
    a.defensePlan?.encounter === "egress" &&
    clearExit(g, a, dt)
  ) {
    a.activity = "defending";
    return;
  }
  if (immediateThreat || committedRetreat) {
    delete a.furnitureYield;
    attention = near && near.hp > 0 && distance(a, near) < 2 ? 0.05 : 0.2;
    a.activity = "fleeing";
    delete a.station;
    if (
      !a.fleeTarget ||
      a.fleeFloor !== a.floor ||
      g.time >= (a.fleeUntil ?? 0) ||
      distance(a, a.fleeTarget) < 0.8 ||
      enemies.some((z) => z.hp > 0 && distance(z, a.fleeTarget!) < 1.1) ||
      (a.path.length > 0 &&
        enemies.some(
          (z) =>
            z.hp > 0 &&
            !a.fleeRouteThreats?.includes(z.id) &&
            routeContacts(a, a.path, [z]) > 0,
        ))
    ) {
      a.fleeTarget = chooseRetreat(g, a, planningThreats, pickup);
      a.fleeUntil = g.time + 3;
      a.fleeFloor = a.floor;
      // A changed threat can invalidate the route even when the replacement
      // destination is close to the old one. Follow must honor the new choice.
      a.path = [];
      a.repath = 0;
      delete a.navTarget;
      const route = a.fleeTarget ? survivorPath(f, a, a.fleeTarget) : [];
      a.fleeRouteThreats = planningThreats
        .filter((z) => routeContacts(a, route, [z]) > 0)
        .map((z) => z.id);
    }
    if (a.fleeTarget) follow(g, a, a.fleeTarget, dt);
    if (a.hp < 45) {
      const med = a.inventory.find((i) => i.kind === "medkit");
      if (med) useItem(g, a, med.id);
    }
  } else if (yieldFurniture(g, a, dt)) {
    attention = 0.2;
  } else if (a.floor === CONFIG.floors) {
    a.activity = "climbing";
    delete a.station;
    follow(g, a, { x: 21.5, y: 10.5 }, dt);
    board(g, a);
  } else if (a.access.includes(a.floor)) {
    a.activity = "climbing";
    delete a.station;
    a.intent = undefined;
    if (clearExit(g, a, dt)) {
      a.activity = "defending";
      return;
    }
    follow(g, a, f.stairs, dt);
    stairs(g, a);
  } else {
    // Local exploration: choose visible available stations, never use a station remotely.
    const candidates = f.stations.filter(
      (s) =>
        a.seen.includes(s.id) &&
        g.encounters[s.encounter].state !== "consumed" &&
        (!g.encounters[s.encounter].owner ||
          g.encounters[s.encounter].owner === a.id ||
          g.encounters[s.encounter].mode === "shared") &&
        (g.encounters[s.encounter].reward === "stairs" ||
          (a.inventory.reduce((n, i) => n + i.weight, 0) < 3 &&
            (a.role === "medic" || a.risk > 0.65))),
    );
    let e = a.intent ? g.encounters[a.intent] : undefined;
    if (
      !e ||
      e.state === "consumed" ||
      e.floor !== a.floor ||
      (e.mode === "solo" && e.owner && e.owner !== a.id)
    ) {
      let chosen: (typeof candidates)[number] | undefined;
      const search = a.taskSearch;
      if (
        !search ||
        search.floor !== a.floor ||
        search.seen !== a.seen.length ||
        g.time >= search.after
      ) {
        chosen = chooseTaskStation(g, a, candidates);
        a.taskSearch = {
          floor: a.floor,
          seen: a.seen.length,
          after: chosen ? 0 : g.time + 1,
          station: enemies.some((z) => z.hp > 0) ? chosen?.id : undefined,
        };
      }
      e = chosen ? g.encounters[chosen.encounter] : undefined;
      a.intent = e?.id;
      delete a.station;
      a.thought = 0;
      a.milestone = 0;
    }
    if (!e) {
      a.activity = "exploring";
      delete a.station;
      a.failedExplore = (a.failedExplore ?? [])
        .filter((v) => v.until > g.time)
        .slice(-24);
      const failed = (p: Point) =>
        a.failedExplore!.some(
          (v) => v.floor === a.floor && distance(v.point, p) < 0.4,
        );
      if (a.exploringDoor && a.exploringDoor.floor !== a.floor) {
        delete a.exploringDoor;
        delete a.target;
      }
      if (a.target && distance(a, a.target) < (a.exploringDoor ? 0.35 : 0.7)) {
        rememberPlace(a, `explored-${a.floor}-${a.target.x}-${a.target.y}`);
        if (a.exploringDoor) {
          delete a.exploringDoor;
        }
        delete a.target;
      }
      if (a.y >= 28) {
        a.target = { ...f.entry };
      }
      if (!a.target) {
        const entry = f.furniture
          .filter(
            (o) =>
              o.kind === "door" &&
              !a.seen.includes(`entered-door-${o.id}`) &&
              !failed(o) &&
              canSee(f, a, o, sightRadius(f), o.id),
          )
          .map((door) => ({ door, goal: doorwayGoal(f, a, door) }))
          .filter(
            (entry): entry is { door: Furniture; goal: Point } =>
              !!entry.goal && !failed(entry.goal),
          )
          .sort((b, c) => distance(a, b.door) - distance(a, c.door))[0];
        if (entry) {
          a.target = { ...entry.goal };
          a.exploringDoor = {
            id: entry.door.id,
            floor: a.floor,
            goal: { ...entry.goal },
          };
          a.repath = 0;
        }
      }
      if (!a.target) {
        const visibleRange = f.dark > 0.8 ? 5.4 : f.dark > 0.3 ? 8 : 11;
        const candidates: { point: Point; score: number }[] = [];
        for (let y = 3; y < 28; y++)
          for (let x = 3; x < 42; x++) {
            if (!explorationCell(f, x, y)) continue;
            const p = { x: x + 0.5, y: y + 0.5 };
            if (
              distance(a, p) < 1 ||
              distance(a, p) > visibleRange ||
              solid(f, p) ||
              failed(p) ||
              !canSee(f, a, p, visibleRange) ||
              a.seen.includes(`explored-${a.floor}-${p.x}-${p.y}`)
            )
              continue;
            candidates.push({
              point: p,
              score:
                (x < 17 || x > 26 ? 4 : 0) + distance(a, p) * 0.1 + rand(g) * 4,
            });
          }
        a.target = candidates.sort((b, c) => c.score - b.score)[0]?.point;
        a.repath = 0;
      }
      // Keep this exploration destination until arrival. Recomputing the
      // opposite hall end from current Y flipped direction at the midline.
      if (!a.target) {
        const preferred = { x: 21.5, y: a.y > 15 ? 10 : 23 };
        const options: Point[] = [preferred];
        for (let y = 3; y < 28; y += 2)
          for (let x = 18; x < 26; x++)
            options.push({ x: x + 0.5, y: y + 0.5 });
        a.target = options
          .filter((p) => !solid(f, p) && !failed(p) && distance(a, p) > 1)
          .sort((b, c) => distance(b, preferred) - distance(c, preferred))[0];
      }
      if (!a.target) return;
      const before = { x: a.x, y: a.y };
      follow(g, a, a.target, dt);
      a.exploreStall =
        distance(before, a) < 0.001 && !a.vault
          ? (a.exploreStall ?? 0) + dt
          : 0;
      if (a.exploreStall > 3 && a.target && distance(a, a.target) > 0.7) {
        a.failedExplore.push({
          point: { ...a.target },
          floor: a.floor,
          until: g.time + 30,
        });
        if (a.exploringDoor) {
          const door = f.furniture.find((o) => o.id === a.exploringDoor!.id);
          if (door)
            a.failedExplore.push({
              point: { x: door.x, y: door.y },
              floor: a.floor,
              until: g.time + 30,
            });
          delete a.exploringDoor;
        }
        delete a.target;
        delete a.navTarget;
        a.path = [];
        a.repath = 0;
        a.exploreStall = 0;
      }
    } else {
      // Cautious solo students also prepare their physical room before work.
      // This never substitutes for their own puzzle or grants a credential.
      // Shared defenders can help a full group without occupying a seat.
      if (
        (a.defensePlan?.encounter === e.id ||
          (e.mode === "solo"
            ? a.role === "builder" || a.risk < 0.7
            : !e.contributors.includes(a.id) &&
              (a.role === "builder" || (a.social > 0.7 && a.risk < 0.7)))) &&
        fortify(g, a, e, dt)
      ) {
        a.activity = "defending";
        if (npcReasoningAvailable(e, a))
          a.thought += dt * 0.15 * (0.65 + taskSkill(a, e) * 0.7);
        return;
      }
      // Reserve a stable physical station. Re-sorting and indexing on every frame
      // made agents switch destinations whenever their relative distances changed.
      const stations = f.stations.filter((s) => s.encounter === e!.id);
      const usable = stations.filter(
        (s) =>
          !g.survivors.some(
            (b) =>
              b.id !== a.id &&
              b.alive &&
              !b.escaped &&
              b.floor === a.floor &&
              b.station === s.id &&
              b.intent === e!.id &&
              b.activity !== "fleeing",
          ),
      );
      let st = usable.find((s) => s.id === a.station);
      if (!st) {
        st =
          usable.find(
            (s) =>
              a.taskSearch?.floor === a.floor && s.id === a.taskSearch.station,
          ) ??
          (enemies.some((z) => z.hp > 0)
            ? chooseTaskStation(g, a, usable)
            : undefined) ??
          usable.sort((b, c) => distance(a, b) - distance(a, c))[0];
        a.station = st?.id;
        if (st)
          a.taskSearch = {
            floor: a.floor,
            seen: a.seen.length,
            after: 0,
            station: st.id,
          };
      }
      if (!st) {
        // A full station cluster is not remotely usable. Look for another
        // opportunity, or physically help defend this shared encounter.
        const other = candidates.find((s) => s.encounter !== e!.id);
        if (other) {
          a.intent = undefined;
          delete a.station;
          delete a.target;
        }
        a.activity = "waiting";
        return;
      }
      a.activity = "studying";
      const room = Number(/room(\d+)/.exec(e.id)?.[1]);
      const roomDoor = f.furniture.find(
        (o) =>
          o.kind === "door" &&
          distance(o, f.doors[room] ?? { x: -100, y: -100 }) < 0.1,
      );
      if (
        roomDoor?.open &&
        (room % 2 === 0 ? a.x < roomDoor.x - 0.7 : a.x > roomDoor.x + 0.7) &&
        distance(a, roomDoor) < 1.9
      )
        toggleDoor(g, a, roomDoor.id, false);
      follow(g, a, st, dt);
      if (distance(a, st) < 1.3 && !a.vault && claimStation(g, a, st.id)) {
        attention = 1;
        if (e.mode === "solo") e.owner ??= a.id;
        if (e.state === "available") e.state = "in-progress";
        if (npcReasoningAvailable(e, a) && a.thought > 24 * (a.milestone + 1)) {
          a.milestone++;
          const mistake = rand(g) > 0.6 + taskSkill(a, e) * 0.3;
          e.npcProgress += recordNpcWork(g, e, a, mistake);
          if (!e.contributors.includes(a.id)) e.contributors.push(a.id);
          if (mistake) a.thought = Math.max(0, a.thought - 15);
        }
        if (e.npcProgress >= 1 && e.state !== "consumed") {
          // NPC-only outcomes are world simulation, never learner evidence. Human-involved work requires the completion adapter.
          const humanWork = hasHumanStudyContext(e);
          if (!humanWork)
            complete(
              g,
              e.id,
              `npc-sim-${e.id}`,
              e.contributors,
              "Simulated NPC-only outcome; no runtime execution or human mastery.",
            );
        }
      }
    }
  }
  if (
    a.intent &&
    g.encounters[a.intent]?.state !== "consumed" &&
    npcReasoningAvailable(g.encounters[a.intent], a)
  )
    a.thought +=
      dt *
      attention *
      (0.65 + taskSkill(a, g.encounters[a.intent]) * 0.7) *
      (1 + (a.role === "analyst" ? 0.2 : 0));
}
export function complete(
  g: Game,
  id: string,
  submissionId: string,
  contributors: string[],
  provenance: string,
) {
  const e = g.encounters[id];
  if (!e || e.state === "consumed") return false;
  e.state = "consumed";
  // A one-use world lock is unavailable for unfinished study. A later valid
  // assessment may still settle this exact attempt, without binding the next task here.
  if (g.study.learner) interruptLearningAttempt(g.study.learner, e);
  e.accepted = submissionId;
  const submission = e.submissions.find((s) => s.id === submissionId);
  if (submission) {
    submission.status = "complete";
    submission.feedback = provenance;
    e.workspace = submission.content;
    e.revision = submission.revision;
  }
  e.chatOpen = false;
  for (const id of new Set(contributors)) {
    const a = g.survivors.find((s) => s.id === id);
    if (!a || !a.alive || a.escaped) continue;
    if (e.reward === "stairs" && !a.access.includes(e.floor))
      a.access.push(e.floor);
  }
  const ev = event(
    g,
    "completion",
    `${e.mode === "shared" ? "Shared" : "Solo"} ${e.reward === "stairs" ? "stair credential" : "cache"} unlocked. ${provenance}`,
    e.floor,
    undefined,
    e.id,
  );
  e.history.push({
    seq: ev.seq,
    author: "system",
    kind: "completion",
    text: ev.text,
    at: g.time,
    revision: e.revision,
  });
  if (submissionId === `npc-sim-${e.id}` && !hasHumanStudyContext(e))
    e.simulatedOutcome = structuredClone({
      id: submissionId,
      runId: g.id,
      revision: e.revision,
      workspace: e.workspace,
      at: g.time,
      cutoff: ev.seq,
      contributors: [...new Set(contributors.filter((id) => id !== "human"))],
      ...(e.problem ? { problem: e.problem } : {}),
      work: (e.npcWork ?? []).filter((w) => w.seq <= ev.seq).slice(-16),
    });
  return true;
}
// Resolve physical crowding with bounded local steps. New arrivals are placed
// in free outside slots; this also lets legacy overlapping saves separate by
// walking, without teleporting or passing through a wall/barricade.
function clearWallSegment(f: Floor, a: Point, b: Point) {
  const samples = Math.max(1, Math.ceil(distance(a, b) / 0.15));
  for (let i = 0; i <= samples; i++)
    for (const dx of [-0.22, 0.22])
      for (const dy of [-0.22, 0.22])
        if (
          wall(
            f,
            a.x + ((b.x - a.x) * i) / samples + dx,
            a.y + ((b.y - a.y) * i) / samples + dy,
          )
        )
          return false;
  return true;
}
function moveZombie(
  g: Game,
  z: Zombie,
  toward: Point,
  amount: number,
  crowd: ZombieIndex,
) {
  const f = g.floors[z.floor],
    others = crowd
      .near(z.floor, z, Math.max(1, 0.43 + amount))
      .filter((o) => o !== z);
  const overlap = (p: Point) =>
    others.reduce((n, o) => n + Math.max(0, 0.43 - distance(o, p)) ** 2, 0);
  const oldOverlap = overlap(z),
    angle = Math.atan2(toward.y - z.y, toward.x - z.x);
  const parity = Number(z.id.replace(/\D/g, "")) % 2 ? 1 : -1;
  for (const offset of [
    0,
    (Math.PI / 6) * parity,
    (-Math.PI / 6) * parity,
    (Math.PI / 3) * parity,
    (-Math.PI / 3) * parity,
    (Math.PI / 2) * parity,
    (-Math.PI / 2) * parity,
  ]) {
    const p = { x: z.x, y: z.y };
    move(
      f,
      p,
      Math.cos(angle + offset) * amount,
      Math.sin(angle + offset) * amount,
    );
    if (distance(p, z) < 0.0001) continue;
    if (!clearWallSegment(f, p, toward)) continue;
    const nextOverlap = overlap(p);
    if (
      nextOverlap > 0.0000001 &&
      (oldOverlap < 0.0000001 || nextOverlap >= oldOverlap - 0.000001)
    )
      continue;
    Object.assign(z, p);
    return true;
  }
  // Give the front of a queue room to align with a narrow opening. A
  // follower may step back or sideways at normal speed; it still observes
  // solid geometry and body separation. This also unwinds existing arches.
  const destination = z.target ?? toward;
  const rank = (a: Zombie) => distance(a, destination);
  const leader = others
    .filter(
      (o) =>
        distance(o, z) < 1 &&
        (rank(o) < rank(z) - 0.01 ||
          (Math.abs(rank(o) - rank(z)) <= 0.01 && o.id < z.id)),
    )
    .sort((a, b) => rank(a) - rank(b))[0];
  if (leader) {
    const away = Math.atan2(z.y - leader.y, z.x - leader.x);
    for (const offset of [
      0,
      Math.PI / 4,
      -Math.PI / 4,
      Math.PI / 2,
      -Math.PI / 2,
    ]) {
      const p = { x: z.x, y: z.y };
      move(
        f,
        p,
        Math.cos(away + offset) * amount,
        Math.sin(away + offset) * amount,
      );
      if (distance(p, z) < 0.0001 || distance(p, leader) <= distance(z, leader))
        continue;
      const nextOverlap = overlap(p);
      if (
        nextOverlap > 0.0000001 &&
        (oldOverlap < 0.0000001 || nextOverlap >= oldOverlap - 0.000001)
      )
        continue;
      Object.assign(z, p);
      return true;
    }
  }
  return false;
}
function strikeSurvivor(
  g: Game,
  z: Zombie,
  prey: Actor,
  floor: number,
  position: Point,
) {
  prey.hp -= g.surge.state === "active" ? 21 : 14;
  const hit = event(
    g,
    "survivor-hit",
    "A zombie attack struck a survivor.",
    floor,
    z.id,
  );
  hit.position = { x: position.x, y: position.y };
  if (floor !== z.floor) hit.stairContact = true;
  z.cooldown = 0.95;
  if (prey.hp <= 0) death(g, prey);
}
function strikeFurniture(
  g: Game,
  z: Zombie,
  ob: Furniture,
  floor: number,
  position: Point,
) {
  ob.hp -= g.surge.state === "active" ? 7 : 4;
  const hit = event(
    g,
    "barricade-hit",
    "A zombie struck a barricade.",
    floor,
    z.id,
  );
  hit.position = { x: position.x, y: position.y };
  if (floor !== z.floor) hit.stairContact = true;
  z.cooldown = 1.25;
  if (ob.hp <= 0) {
    ob.destroyed = true;
    ob.hp = 0;
    g.stats.breaches++;
    event(
      g,
      "breach",
      `A ${ob.kind === "gate" ? "main entrance" : ob.kind} broke apart.`,
      floor,
    ).position = { x: position.x, y: position.y };
  }
}
function zombie(
  g: Game,
  z: Zombie,
  dt: number,
  contacts: Map<string, number>,
  crowd: ZombieIndex,
) {
  z.stagger = Math.max(0, z.stagger - dt);
  z.cooldown = Math.max(0, z.cooldown - dt);
  if (z.hp <= 0 || z.stagger > 0) return;
  const arrival = zombieStairArrival(g, z, crowd);
  if (arrival) {
    if (arrival.kind === "cancel") delete z.stairUntil;
    else {
      if (arrival.kind === "arrive") {
        z.floor = arrival.floor;
        Object.assign(z, arrival.position);
        delete z.stairUntil;
        z.path = [];
        delete z.target;
        z.memory = 0;
        z.repath = 0;
        event(
          g,
          "horde-climb",
          "The horde reached a higher floor.",
          z.floor,
          z.id,
        );
      } else if (arrival.kind === "furniture" || arrival.kind === "survivor") {
        const key = `stair-exit/${z.floor}/${arrival.floor}`;
        if (!contacts.has(key)) {
          contacts.set(key, 1);
          if (z.cooldown <= 0) {
            if (arrival.kind === "furniture")
              strikeFurniture(
                g,
                z,
                arrival.object,
                arrival.floor,
                arrival.position,
              );
            else
              strikeSurvivor(
                g,
                z,
                arrival.actor,
                arrival.floor,
                arrival.position,
              );
          }
        }
      }
      return;
    }
  }
  const f = g.floors[z.floor];
  let prey = g.survivors
    .filter(
      (a) =>
        a.floor === z.floor &&
        a.alive &&
        !a.escaped &&
        canSee(f, z, a, 12, a.vault?.obstacle),
    )
    .sort((a, b) => distance(a, z) - distance(b, z))[0];
  const decoy = g.effects
    .filter(
      (e) =>
        e.kind === "decoy" &&
        e.until > g.time &&
        e.floor === z.floor &&
        distance(e, z) < e.radius * soundGain(f, z, e),
    )
    .sort((a, b) => distance(z, a) - distance(z, b))[0];
  if (prey) {
    z.target = { x: prey.x, y: prey.y };
    z.memory = g.time + 9;
  } else {
    const heard =
      z.repath <= 0
        ? g.survivors
            .filter(
              (a) =>
                a.floor === z.floor &&
                a.alive &&
                !a.escaped &&
                (a.noiseUntil ?? 0) > g.time &&
                distance(a, z) < (a.noiseLevel ?? 0),
            )
            .sort((a, b) => distance(z, a) - distance(z, b))
            .slice(0, 3)
            .find(
              (a) => distance(a, z) < (a.noiseLevel ?? 0) * soundGain(f, z, a),
            )
        : undefined;
    if (heard) {
      z.target = { x: heard.x, y: heard.y };
      z.memory = g.time + 5;
    } else if (g.time > z.memory) z.target = undefined;
  }
  let target =
    decoy ??
    z.target ??
    (z.floor === CONFIG.floors ? { x: 21.5, y: 10.5 } : f.stairs);
  const bubble = g.effects.find(
    (e) =>
      e.kind === "bubble" &&
      e.until > g.time &&
      e.floor === z.floor &&
      canSee(f, e, z, e.radius + 0.5),
  );
  if (bubble) {
    const d = distance(z, bubble) || 1;
    move(
      f,
      z,
      ((z.x - bubble.x) / d) * dt * 3,
      ((z.y - bubble.y) / d) * dt * 3,
    );
    return;
  }
  const surge = g.surge.state === "active";
  if (
    prey &&
    distance(z, prey) < 0.78 &&
    line(f, z, prey, true, prey.vault?.obstacle) &&
    z.cooldown <= 0
  ) {
    strikeSurvivor(g, z, prey, z.floor, z);
    return;
  }
  z.repath -= dt;
  if (z.repath <= 0) {
    z.path = path(f, z, target, true);
    z.repath = 1.2 + rand(g) * 0.6;
  }
  let p = z.path[0];
  if (p && distance(z, p) < 0.17) {
    z.path.shift();
    p = z.path[0];
  }
  // A waypoint is a route guide, not a point every member of a crowd must
  // occupy. Skip a nearby guide only when the next swept segment is clear.
  while (
    z.path.length > 1 &&
    distance(z, z.path[0]) < 0.7 &&
    walkSegment(f, z, z.path[1])
  )
    z.path.shift();
  p = z.path[0];
  if (p && !clearWallSegment(f, z, p))
    p = { x: Math.floor(z.x) + 0.5, y: Math.floor(z.y) + 0.5 };
  // Grid search has no edge when both positions share a cell. Finish the
  // remaining physical distance instead of freezing just outside attack range.
  if (!p && !solid(f, target) && line(f, z, target, true)) p = target;
  if (p) {
    const d = distance(z, p) || 1,
      dx = (p.x - z.x) / d,
      dy = (p.y - z.y) / d;
    const ob = f.furniture.find((o) =>
      inFurniture({ x: z.x + dx * 0.55, y: z.y + dy * 0.55 }, o, 0.23),
    );
    if (ob) {
      const surface = {
        x: Math.max(ob.x - ob.w / 2, Math.min(z.x, ob.x + ob.w / 2)),
        y: Math.max(ob.y - ob.h / 2, Math.min(z.y, ob.y + ob.h / 2)),
      };
      if (distance(z, surface) > 0.42) {
        moveZombie(
          g,
          z,
          p,
          Math.min(CONFIG.zombieSpeed * (surge ? 1.35 : 1) * dt, d),
          crowd,
        );
        return;
      }
      const horizontal =
        Math.abs(z.x - ob.x) / (ob.w / 2) > Math.abs(z.y - ob.y) / (ob.h / 2);
      const face = horizontal
        ? z.x < ob.x
          ? "west"
          : "east"
        : z.y < ob.y
          ? "north"
          : "south";
      const slots = Math.max(1, Math.floor(horizontal ? ob.h : ob.w)),
        key = `${ob.id}/${face}`,
        n = contacts.get(key) ?? 0;
      const positionKey = `${key}/${Math.floor(horizontal ? surface.y : surface.x)}`;
      if (n >= slots || contacts.has(positionKey)) return;
      // A contacting attacker occupies its face slot throughout its cooldown.
      // Otherwise alternating queued attackers multiply DPS between frames.
      contacts.set(key, n + 1);
      contacts.set(positionKey, 1);
      if (z.cooldown <= 0) {
        strikeFurniture(g, z, ob, z.floor, z);
      }
      return;
    }
    const step = CONFIG.zombieSpeed * (surge ? 1.35 : 1) * dt;
    moveZombie(g, z, p, Math.min(step, d), crowd);
  }
  if (z.floor < CONFIG.floors && distance(z, f.stairs) < 0.75) {
    z.stairUntil = g.time + CONFIG.stairSeconds;
    event(
      g,
      "horde-stairs",
      "A zombie entered the stair flight.",
      z.floor,
      z.id,
    );
  }
}
export function useItem(g: Game, a: Actor, id: string) {
  const it = a.inventory.find((i) => i.id === id);
  const issue = itemUseIssue(g, a, it);
  if (issue) {
    if (a === human(g)) g.notice = issue;
    return false;
  }
  if (!it) return false;
  switch (it.kind) {
    case "medkit":
      a.hp = Math.min(100, a.hp + EQUIPMENT.medkit.heal);
      break;
    case "bubble":
      g.effects.push({
        kind: "bubble",
        floor: a.floor,
        x: a.x,
        y: a.y,
        radius: EQUIPMENT.bubble.radius,
        until: g.time + EQUIPMENT.bubble.seconds,
      });
      break;
    case "flare":
      g.effects.push({
        kind: "flare",
        floor: a.floor,
        x: a.x,
        y: a.y,
        radius: EQUIPMENT.flare.radius,
        until: g.time + EQUIPMENT.flare.seconds,
      });
      break;
    case "decoy":
      g.effects.push({
        kind: "decoy",
        floor: a.floor,
        x: a.x,
        y: a.y,
        radius: EQUIPMENT.decoy.radius,
        until: g.time + EQUIPMENT.decoy.seconds,
      });
      break;
    case "battery":
      g.effects.push({
        kind: "flare",
        floor: a.floor,
        x: a.x,
        y: a.y,
        radius: EQUIPMENT.battery.radius,
        until: g.time + EQUIPMENT.battery.seconds,
      });
      break;
    case "repulsor":
    case "weapon":
      for (const z of itemTargets(g, a, it.kind)) {
        if (it.kind === "weapon")
          z.hp = Math.max(0, z.hp - EQUIPMENT.weapon.damage);
        else knockback(g, z, a);
      }
      break;
  }
  it.charges--;
  if (it.charges <= 0) a.inventory = a.inventory.filter((i) => i !== it);
  event(g, "item", `${a.name} used a ${it.kind}.`, a.floor, a.id);
  return true;
}
function knockback(g: Game, z: Zombie, from: Point) {
  const d = distance(z, from) || 1;
  for (let i = 0; i < 12; i++)
    move(
      g.floors[z.floor],
      z,
      ((z.x - from.x) / d) * 0.25,
      ((z.y - from.y) / d) * 0.25,
    );
  z.stagger = 2.5;
  z.path = [];
}
export function takeLoot(g: Game, a: Actor, id: string, itemId: string) {
  const e = g.encounters[id],
    station = g.floors[a.floor].stations.find(
      (s) => s.encounter === id && canReachStation(g, a, s, 2),
    );
  if (
    !station ||
    !e ||
    e.state !== "consumed" ||
    e.reward !== "loot" ||
    !e.contributors.includes(a.id)
  )
    return false;
  const item = e.loot.find((i) => i.id === itemId);
  if (
    !item ||
    a.inventory.reduce((n, i) => n + i.weight, 0) + item.weight >
      CONFIG.capacity
  )
    return false;
  e.loot = e.loot.filter((i) => i !== item);
  a.inventory.push(item);
  event(g, "loot", `${a.name} collected a ${item.kind}.`, a.floor, a.id, e.id);
  return true;
}
export function step(
  g: Game,
  dt: number,
  input: Input = { x: 0, y: 0, grab: false },
) {
  if (g.status !== "playing") return;
  dt = Math.min(dt, 0.1);
  g.time += dt;
  g.tick = (g.tick ?? 0) + 1;
  tickSurge(g);
  for (const e of g.effects.filter((e) => e.until <= g.time))
    if (e.kind === "bubble") {
      for (const z of g.zombies.filter(
        (z) =>
          z.hp > 0 &&
          z.floor === e.floor &&
          canSee(g.floors[e.floor], e, z, e.radius + 1),
      ))
        knockback(g, z, e);
      event(
        g,
        "bubble-end",
        "The shield disperses in a concussive burst.",
        e.floor,
      );
    }
  g.effects = g.effects.filter((e) => e.until > g.time);
  const a = human(g);
  for (const f of g.floors)
    for (const o of f.furniture) {
      o.movers = [];
      if (o.turning > 0) o.turning = Math.max(0, o.turning - dt);
      else if (o.kind === "gate" && o.turning < 0) {
        const next = Math.min(0, o.turning + dt),
          closed = { ...o, turning: 0 };
        const occupied =
          next === 0 &&
          (g.survivors.some(
            (b) =>
              b.floor === f.index &&
              b.alive &&
              !b.escaped &&
              inFurniture(b, closed, 0.22),
          ) ||
            g.zombies.some(
              (z) =>
                z.floor === f.index && z.hp > 0 && inFurniture(z, closed, 0.22),
            ));
        o.turning = occupied ? -dt : next;
        if (o.turning === 0)
          event(
            g,
            "entrance-close",
            "The main entrance slammed shut.",
            f.index,
          );
      }
    }
  if (a.alive && !a.escaped) {
    a.cooldown = Math.max(0, a.cooldown - dt);
    if (a.stairTravel && (input.x || input.y)) cancelStairs(g, a);
    if (advanceStairs(g, a)) {
      /* A committed flight cannot move or interact remotely. */
    } else if (a.vault) advanceVault(a, dt);
    else if (input.x || input.y) {
      const n = Math.hypot(input.x, input.y);
      a.heading = { x: input.x / n, y: input.y / n };
      a.noiseUntil = g.time + 0.4;
      a.noiseLevel = 4;
      if (input.grab) pushFurniture(g, a, input.x, input.y, dt);
      else {
        delete a.handling;
        move(
          g.floors[a.floor],
          a,
          (input.x / n) * a.speed * dt,
          (input.y / n) * a.speed * dt,
        );
      }
    } else if (!input.grab) delete a.handling;
  }
  for (const b of g.survivors.slice(1)) {
    if (!b.alive || b.escaped) continue;
    b.cooldown = Math.max(0, b.cooldown - dt);
    const previous = { activity: b.activity, intent: b.intent, floor: b.floor };
    if (
      b.stairTravel &&
      g.time >= b.stairTravel.until &&
      g.zombies.some(
        (z) =>
          z.hp > 0 && z.floor === b.floor && canSee(g.floors[b.floor], b, z, 4),
      )
    )
      cancelStairs(g, b);
    if (advanceStairs(g, b)) {
      if (
        b.intent &&
        g.encounters[b.intent]?.state !== "consumed" &&
        npcReasoningAvailable(g.encounters[b.intent], b)
      )
        b.thought +=
          dt * 0.2 * (0.65 + taskSkill(b, g.encounters[b.intent]) * 0.7);
    } else if (b.vault) {
      advanceVault(b, dt);
      if (
        b.intent &&
        g.encounters[b.intent]?.state !== "consumed" &&
        npcReasoningAvailable(g.encounters[b.intent], b)
      )
        b.thought +=
          dt * 0.2 * (0.65 + taskSkill(b, g.encounters[b.intent]) * 0.7);
    } else npc(g, b, dt);
    recordNpcActivity(g, b, previous);
  }
  if (g.time >= g.nextSpawn) {
    g.nextSpawn = g.time + CONFIG.spawnInterval;
    const batch =
      g.spawned < CONFIG.openingHorde
        ? Math.min(CONFIG.openingBatch, CONFIG.openingHorde - g.spawned)
        : CONFIG.reinforcementBatch;
    for (let n = 0; n < batch; n++) {
      const positions = Array.from({ length: 12 }, (_, i) => ({
        x: 18.6 + ((i + g.spawned) % 12) * 0.6,
        y: 33.4,
      }));
      const position = positions.find(
        (p) =>
          !solid(g.floors[0], p) &&
          !g.zombies.some(
            (z) => z.floor === 0 && z.hp > 0 && distance(z, p) < 0.55,
          ) &&
          !g.survivors.some(
            (a) =>
              a.floor === 0 && a.alive && !a.escaped && distance(a, p) < 0.55,
          ),
      );
      if (!position) break;
      g.zombies.push({
        id: `z${g.spawned++}`,
        floor: 0,
        ...position,
        hp: 60,
        path: [],
        repath: 0,
        cooldown: 0,
        memory: 0,
        stagger: 0,
        origin: "outside",
      });
    }
  }
  const contacts = new Map<string, number>();
  const crowd = new ZombieIndex(g.zombies);
  for (const z of g.zombies) {
    zombie(g, z, dt, contacts, crowd);
    crowd.update(z);
  }
  const h = g.helicopter;
  if (g.time >= h.next) {
    h.trip++;
    h.passengers = [];
    h.until = g.time + CONFIG.boardingWindow;
    h.next = g.time + CONFIG.helicopterInterval;
    event(
      g,
      "helicopter",
      "A four-seat helicopter is boarding.",
      CONFIG.floors,
    );
  }
}
