// Real protected HTTP/OAuth and synthetic signed connector assertions. No real account token is used.
import test from "node:test";
import { request as httpRequest } from "node:http";
import assert from "node:assert/strict";
import {
  createHash,
  generateKeyPairSync,
  randomBytes,
  randomUUID,
  sign,
} from "node:crypto";
import { mkdtempSync, rmSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
// @ts-expect-error Direct local .mjs security integration.
import { createPublicHandoffBridge } from "../scripts/chatgpt-public-bridge.mjs";
// @ts-expect-error Direct local .mjs security integration.
import { createHandoffQueue } from "../scripts/chatgpt-handoff-queue.mjs";
// @ts-expect-error Direct local .mjs security integration.
import { validateClientMetadata } from "../scripts/chatgpt-security/cimd.mjs";
const hostname = "synthetic-game.lullascape.com",
  issuer = `https://${hostname}`,
  clientId = "https://chatgpt.com/oauth/client.json",
  redirect = "https://chatgpt.com/connector_platform_oauth_redirect";
const metadata = {
  client_id: clientId,
  client_uri: "https://chatgpt.com/",
  redirect_uris: [redirect],
  token_endpoint_auth_method: "private_key_jwt",
  token_endpoint_auth_methods_supported: ["none", "private_key_jwt"],
  grant_types: ["authorization_code", "refresh_token"],
  response_types: ["code"],
  client_name: "ChatGPT",
  token_endpoint_auth_signing_alg: "RS256",
  jwks_uri: "https://chatgpt.com/oauth/jwks.json",
};
const parseTool = (body: any) => JSON.parse(body.result.content[0].text);

async function proxyFetch(
  url: string,
  init: {
    method?: string;
    headers?: Record<string, string>;
    body?: string;
    redirect?: string;
  } = {},
): Promise<Response> {
  return new Promise((resolve, reject) => {
    const req = httpRequest(
      url,
      { method: init.method ?? "GET", headers: init.headers },
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (part) => chunks.push(part));
        res.on("end", () =>
          resolve(
            new Response(Buffer.concat(chunks), {
              status: res.statusCode!,
              headers: Object.fromEntries(
                Object.entries(res.headers)
                  .filter(([, value]) => value !== undefined)
                  .map(([key, value]) => [
                    key,
                    Array.isArray(value) ? value.join(", ") : String(value),
                  ]),
              ),
            }),
          ),
        );
      },
    );
    req.on("error", reject);
    req.end(init.body);
  });
}

test("separate game connector requires local pairing, PKCE, a signed client assertion, OAuth, permitted proxy source and current worker session", async () => {
  const dir = mkdtempSync(join(tmpdir(), "dead-air-public-")),
    q = createHandoffQueue();
  const keys = generateKeyPairSync("rsa", { modulusLength: 2048 }),
    jwk = {
      ...keys.publicKey.export({ format: "jwk" }),
      kid: "controlled-public-key",
      alg: "RS256",
      use: "sig",
    };
  const bridge = createPublicHandoffBridge({
    hostname,
    queue: q,
    directory: dir,
    connectorRanges: ["203.0.113.0/24"],
    fetchClientMetadata: async () => validateClientMetadata(metadata, clientId),
    fetchJwks: async () => ({ keys: [jwk] }),
  });
  await new Promise<void>((resolve) =>
    bridge.server.listen(0, "127.0.0.1", resolve),
  );
  const address = bridge.server.address();
  assert.ok(address && typeof address !== "string");
  const base = `http://127.0.0.1:${address.port}`;
  const headers = { Host: hostname, "CF-Connecting-IP": "203.0.113.10" };
  const post = async (
    path: string,
    body: unknown,
    extra: Record<string, string> = {},
  ) =>
    proxyFetch(base + path, {
      method: "POST",
      headers: {
        ...headers,
        "Content-Type": "application/json",
        Accept: "application/json, text/event-stream",
        ...extra,
      },
      body: typeof body === "string" ? body : JSON.stringify(body),
      redirect: "manual",
    });
  const form = (body: Record<string, string>) =>
    new URLSearchParams(body).toString();
  const assertion = () => {
    const header = Buffer.from(
        JSON.stringify({ alg: "RS256", kid: jwk.kid, typ: "JWT" }),
      ).toString("base64url"),
      now = Math.floor(Date.now() / 1000),
      payload = Buffer.from(
        JSON.stringify({
          iss: clientId,
          sub: clientId,
          aud: issuer + "/oauth/token",
          iat: now,
          exp: now + 60,
          jti: randomUUID(),
        }),
      ).toString("base64url"),
      input = header + "." + payload;
    return (
      input +
      "." +
      sign("RSA-SHA256", Buffer.from(input), keys.privateKey).toString(
        "base64url",
      )
    );
  };
  try {
    const discovery = await proxyFetch(
      base + "/.well-known/oauth-protected-resource/mcp",
      { headers },
    );
    assert.equal(discovery.status, 200);
    assert.equal((await discovery.json()).resource, issuer + "/mcp");
    const denied = await post("/mcp", {
      jsonrpc: "2.0",
      id: 1,
      method: "tools/list",
    });
    assert.equal(denied.status, 401);
    assert.equal(
      (await post("/api/bridge", {}, headers)).status,
      404,
      "public listener exposes no local game API",
    );
    const verifier = randomBytes(32).toString("base64url"),
      challenge = createHash("sha256").update(verifier).digest("base64url");
    const query = new URLSearchParams({
      response_type: "code",
      client_id: clientId,
      redirect_uri: redirect,
      state: "controlled-state",
      code_challenge: challenge,
      code_challenge_method: "S256",
      resource: issuer + "/mcp",
      scope: "handoff",
    });
    const closed = await proxyFetch(base + "/oauth/authorize?" + query, {
      headers,
    });
    assert.equal(closed.status, 403);
    const { pairingCode } = bridge.openPairing();
    const consent = await proxyFetch(base + "/oauth/authorize?" + query, {
      headers,
    });
    assert.equal(consent.status, 200);
    const html = await consent.text();
    assert.match(html, /Zombie Study Escape/);
    assert.ok(!html.includes("Infinite Canvas"));
    const txn = /name="txn" value="([^"]+)"/.exec(html)?.[1];
    assert.ok(txn);
    const approved = await post(
      "/oauth/authorize",
      form({ txn, action: "approve", pairing_code: pairingCode }),
      { "Content-Type": "application/x-www-form-urlencoded", Origin: issuer },
    );
    assert.equal(approved.status, 302);
    const returned = new URL(approved.headers.get("location")!);
    assert.equal(returned.origin, "https://chatgpt.com");
    assert.equal(returned.searchParams.get("state"), "controlled-state");
    const code = returned.searchParams.get("code")!;
    const tokenBody = {
      grant_type: "authorization_code",
      code,
      redirect_uri: redirect,
      code_verifier: verifier,
      resource: issuer + "/mcp",
      client_id: clientId,
    };
    const unsigned = await post("/oauth/token", form(tokenBody), {
      "Content-Type": "application/x-www-form-urlencoded",
    });
    assert.equal(
      unsigned.status,
      401,
      "a known code cannot bypass required connector signatures",
    );
    // A failed unsigned request must not consume the valid code before authenticated exchange.
    const tokenResponse = await post(
      "/oauth/token",
      form({
        ...tokenBody,
        client_assertion_type:
          "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
        client_assertion: assertion(),
      }),
      { "Content-Type": "application/x-www-form-urlencoded" },
    );
    assert.equal(tokenResponse.status, 200, await tokenResponse.clone().text());
    const token = await tokenResponse.json();
    assert.equal(bridge.status().linked, true);
    const authorized = { Authorization: `Bearer ${token.access_token}` };
    assert.equal(
      (
        await post(
          "/mcp",
          { jsonrpc: "2.0", id: 2, method: "tools/list" },
          { ...authorized, "CF-Connecting-IP": "198.51.100.9" },
        )
      ).status,
      401,
    );
    assert.equal(
      (
        await post(
          "/mcp",
          { jsonrpc: "2.0", id: 3, method: "tools/list" },
          { ...authorized, Host: "unrelated.example" },
        )
      ).status,
      421,
    );
    const listing = await (
      await post(
        "/mcp",
        { jsonrpc: "2.0", id: 4, method: "tools/list" },
        authorized,
      )
    ).json();
    assert.equal(listing.result.tools.length, 3);
    assert.ok(
      listing.result.tools.every((t: any) =>
        t.inputSchema.required.includes("session"),
      ),
    );
    assert.equal(q.snapshot().enabled, false);
    assert.throws(() => bridge.newWorker(), /Release handoffs/);
    q.enable(true);
    const current = bridge.newWorker(),
      receipt = q.enqueue("tutor", {
        requestId: "protected-tutor",
        problem: { prompt: "Controlled private task" },
      });
    const rpc = async (name: string, args: unknown) =>
      parseTool(
        await (
          await post(
            "/mcp",
            {
              jsonrpc: "2.0",
              id: randomUUID(),
              method: "tools/call",
              params: { name, arguments: args },
            },
            authorized,
          )
        ).json(),
      );
    const wrong = await rpc("get_study_handoff", {
      session: "old-or-unknown-session",
    });
    assert.equal(wrong.status, "rejected");
    assert.equal(q.snapshot().queued, 1);
    const job = await rpc("get_study_handoff", { session: current.session });
    assert.equal(job.payload.requestId, "protected-tutor");
    const sent = await rpc("submit_study_handoff", {
      session: current.session,
      jobId: job.jobId,
      claim: job.claim,
      response: JSON.stringify({ text: "Controlled protected answer" }),
    });
    assert.equal(sent.status, "accepted");
    assert.deepEqual(q.result(receipt.id, receipt.hash).answer, {
      text: "Controlled protected answer",
    });
    bridge.newWorker();
    assert.equal(
      (await rpc("get_study_handoff", { session: current.session })).status,
      "rejected",
    );
    const disk = readFileSync(join(dir, "oauth.json"), "utf8");
    assert.ok(!disk.includes(token.access_token));
    assert.ok(!disk.includes(token.refresh_token));
    assert.ok(!disk.includes(pairingCode));
    bridge.revoke();
    assert.equal(q.snapshot().enabled, false);
    assert.equal(
      (
        await post(
          "/mcp",
          { jsonrpc: "2.0", id: 5, method: "tools/list" },
          authorized,
        )
      ).status,
      401,
    );
  } finally {
    await bridge.close();
    rmSync(dir, { recursive: true, force: true });
  }
});

test("public connector refuses unsafe hostname or bridge directory and starts with no restored worker session", () => {
  const q = createHandoffQueue(),
    dir = mkdtempSync(join(tmpdir(), "dead-air-public-"));
  try {
    for (const hostname of [
      "lullascape.com",
      "infinite.example",
      "https://game.lullascape.com",
      "-bad.lullascape.com",
      "game.lullascape.com.evil.invalid",
    ])
      assert.throws(
        () => createPublicHandoffBridge({ hostname, queue: q, directory: dir }),
        /distinct game hostname/,
      );
    const bridge = createPublicHandoffBridge({
      hostname,
      queue: q,
      directory: dir,
    });
    assert.equal(bridge.status().workerActive, false);
    assert.equal(bridge.status().linked, false);
    assert.ok(bridge.openPairing().pairingCode);
    assert.equal(bridge.status().pairingOpen, true);
    assert.equal(q.snapshot().enabled, false);
    assert.equal(q.snapshot().queued, 0);
    bridge.closePairing();
    assert.equal(bridge.status().pairingOpen, false);
    assert.throws(() => bridge.newWorker(), /Release handoffs/);
    void bridge.close();
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
