import { type Floor, type Game, type Point, H, W, distance } from "./model";
import { wall } from "./spatial";

// Four cells per world unit: permanent coverage has a fixed upper bound of
// W*H*16 characters per floor, rather than one saved object per footstep.
export const BLOOD_RESOLUTION = 4;
const width = W * BLOOD_RESOLUTION;
function stain(f: Floor, p: Point) {
  if (wall(f, p.x, p.y)) return;
  const x = Math.floor(p.x * BLOOD_RESOLUTION),
    y = Math.floor(p.y * BLOOD_RESOLUTION);
  if (x < 0 || x >= width || y < 0 || y >= H * BLOOD_RESOLUTION) return;
  const rows = (f.blood ??= []),
    row = (rows[y] ?? "").padEnd(width, "0"),
    level = Math.min(3, Number(row[x]) + 1).toString();
  rows[y] = row.slice(0, x) + level + row.slice(x + 1);
}
export function recordZombieTrails(g: Game) {
  for (const z of g.zombies) {
    if (z.hp <= 0) continue;
    const previous = z.bloodStep;
    if (
      !previous ||
      previous.floor !== z.floor ||
      distance(previous, z) > 1.5
    ) {
      z.bloodStep = { x: z.x, y: z.y, floor: z.floor };
      continue;
    }
    const d = distance(previous, z),
      steps = Math.floor(d / 0.22);
    for (let i = 1; i <= steps; i++)
      stain(g.floors[z.floor], {
        x: previous.x + ((z.x - previous.x) * i * 0.22) / d,
        y: previous.y + ((z.y - previous.y) * i * 0.22) / d,
      });
    if (steps)
      z.bloodStep = {
        x: previous.x + ((z.x - previous.x) * steps * 0.22) / d,
        y: previous.y + ((z.y - previous.y) * steps * 0.22) / d,
        floor: z.floor,
      };
  }
}
const layers = new WeakMap<
  Floor,
  { canvas: HTMLCanvasElement; rows: (string | undefined)[] }
>();
export function drawBlood(ctx: CanvasRenderingContext2D, f: Floor) {
  if (!f.blood) return;
  let layer = layers.get(f);
  if (!layer) {
    const canvas = document.createElement("canvas");
    canvas.width = W * 16;
    canvas.height = H * 16;
    layer = { canvas, rows: [] };
    layers.set(f, layer);
  }
  const ink = layer.canvas.getContext("2d")!;
  for (let y = 0; y < H * BLOOD_RESOLUTION; y++) {
    const row = f.blood[y];
    if (row === layer.rows[y]) continue;
    ink.clearRect(0, y * 4, layer.canvas.width, 4);
    for (let x = 0; x < Math.min(width, row?.length ?? 0); x++) {
      const level = Number(row![x]);
      if (!(level > 0)) continue;
      const variant = (x * 17 + y * 31) % 7;
      ink.fillStyle = ["", "#76272b", "#702125", "#57181e"][Math.min(3, level)];
      ink.beginPath();
      ink.ellipse(
        x * 4 + 2,
        y * 4 + 2,
        1.2 + variant * 0.1,
        0.8 + level * 0.28,
        variant,
        0,
        Math.PI * 2,
      );
      ink.fill();
      ink.fillStyle = "#a33d38";
      ink.fillRect(x * 4 + (variant % 3), y * 4 + 1, 0.7, 0.7);
    }
    layer.rows[y] = row;
  }
  ctx.drawImage(layer.canvas, 0, 0, W, H);
}
