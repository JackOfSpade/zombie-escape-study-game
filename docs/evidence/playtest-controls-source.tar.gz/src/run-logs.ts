import type { Game } from "./model";
export const LOG_KEY = "recent-game-diagnostics-v1";
export const LOG_LIMITS = { games: 3, entries: 400, bytesPerGame: 256_000 };
interface Entry {
  at: number;
  type: string;
  data: unknown;
}
interface RunLog {
  id: string;
  seed: number;
  started: string;
  entries: Entry[];
}
interface LogStorage {
  read(): Promise<string | null>;
  write(value: string): Promise<void>;
}
/** Diagnostics have their own retention policy; pruning never touches learning saves. */
export class RunLogs {
  runs: RunLog[] = [];
  error = "";
  private queue = Promise.resolve();
  private observed = new Map<string, { seq: number; time: number }>();
  constructor(private storage: LogStorage) {}
  async load() {
    try {
      const raw = await this.storage.read();
      if (raw) {
        const data = JSON.parse(raw);
        if (data.version === 1 && Array.isArray(data.runs))
          this.runs = data.runs
            .filter(
              (r: RunLog) =>
                typeof r.id === "string" && Array.isArray(r.entries),
            )
            .slice(-LOG_LIMITS.games);
      }
      for (const run of this.runs) this.trim(run);
    } catch {
      this.error = "Could not read previous game logs.";
    }
  }
  private trim(run: RunLog) {
    if (run.entries.length > LOG_LIMITS.entries)
      run.entries.splice(0, run.entries.length - LOG_LIMITS.entries);
    while (
      new TextEncoder().encode(JSON.stringify(run)).byteLength >
        LOG_LIMITS.bytesPerGame &&
      run.entries.length
    )
      run.entries.shift();
  }
  record(g: Game, type: string, data: unknown = null) {
    let run = this.runs.find((r) => r.id === g.id);
    if (!run) {
      run = {
        id: g.id,
        seed: g.seed,
        started: new Date().toISOString(),
        entries: [],
      };
      this.runs.push(run);
      this.runs = this.runs.slice(-LOG_LIMITS.games);
      for (const id of this.observed.keys())
        if (!this.runs.some((r) => r.id === id)) this.observed.delete(id);
    }
    run.entries.push({ at: Math.round(g.time * 100) / 100, type, data });
    this.trim(run);
  }
  capture(g: Game, force = false) {
    if (g.status === "ready") return;
    const previous = this.observed.get(g.id);
    if (
      !force &&
      g.status === "playing" &&
      previous &&
      g.time - previous.time < 2 &&
      previous.time <= g.time
    )
      return;
    for (const e of g.events.filter((e) => e.seq > (previous?.seq ?? 0)))
      this.record(g, "world", {
        seq: e.seq,
        type: e.type,
        actor: e.actor,
        floor: e.floor,
      });
    const round = (n: number) => Math.round(n * 100) / 100;
    this.record(g, "snapshot", {
      status: g.status,
      paused: !!g.paused,
      actors: g.survivors.map((a) => ({
        id: a.id,
        floor: a.floor,
        x: round(a.x),
        y: round(a.y),
        hp: round(a.hp),
        alive: a.alive,
        escaped: a.escaped,
        activity: a.activity,
        handling: a.handling,
        blocked: a.blockedTime,
        path: a.path.slice(0, 2),
        plan: a.defensePlan && {
          object: a.defensePlan.object,
          idle: a.defensePlan.idle,
          target: a.defensePlan.target,
        },
      })),
      furniture: g.floors.flatMap((f) =>
        f.furniture
          .filter((o) => o.moved > 0 || o.hp < o.maxHp)
          .map((o) => ({
            id: o.id,
            x: round(o.x),
            y: round(o.y),
            w: o.w,
            h: o.h,
            angle: round(o.angle ?? 0),
            hp: round(o.hp),
            destroyed: o.destroyed,
          })),
      ),
      zombies: g.zombies
        .filter((z) => z.hp > 0)
        .slice(-80)
        .map((z) => ({
          floor: z.floor,
          x: round(z.x),
          y: round(z.y),
          hp: round(z.hp),
        })),
    });
    this.observed.set(g.id, { seq: g.seq, time: g.time });
    this.flush();
  }
  export() {
    return JSON.stringify(
      { version: 1, limits: LOG_LIMITS, runs: this.runs },
      null,
      2,
    );
  }
  flush() {
    // Serialize writes; a slower older write cannot overwrite a newer checkpoint.
    const snapshot = JSON.stringify({ version: 1, runs: this.runs });
    this.queue = this.queue.then(async () => {
      try {
        await this.storage.write(snapshot);
        this.error = "";
      } catch {
        this.error =
          "Game logs could not be saved. Download them before closing.";
      }
    });
    return this.queue;
  }
}
