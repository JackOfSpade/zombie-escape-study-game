import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createGame } from "../src/world";
import { type Roadmap, CONFIG } from "../src/model";
import { step } from "../src/engine";
import { encode, decode } from "../src/persistence";
const r = JSON.parse(readFileSync("public/curriculum.json", "utf8")) as Roadmap;
function fixture() {
  const g = createGame(42, r);
  g.status = "playing";
  g.survivors.forEach((a) => {
    a.escaped = true;
  });
  g.spawned = 90;
  g.time = 1000;
  g.nextSpawn = 1000;
  g.surge.anchor = 999999;
  return g;
}
test("outside arrivals continue after the opening rush without reusing identifiers or changing learning", () => {
  const g = fixture(),
    learning = JSON.stringify(g.study);
  step(g, 1 / 30);
  assert.equal(g.spawned, 91);
  assert.equal(g.zombies.length, 1);
  assert.equal(g.zombies[0].id, "z90");
  assert.equal(g.zombies[0].origin, "outside");
  assert.equal(g.zombies[0].floor, 0);
  assert.ok(g.zombies[0].y > 28);
  const before = g.spawned;
  for (let i = 0; i < 120; i++) step(g, 1 / 30);
  assert.equal(g.spawned, before);
  while (g.time < 1008.1) step(g, 1 / 30);
  assert.equal(g.spawned, 92);
  assert.equal(JSON.stringify(g.study), learning);
});
test("a full upstairs horde does not exhaust later entrance arrivals and old bodies remain physical", () => {
  const g = fixture();
  for (let i = 0; i < 90; i++)
    g.zombies.push({
      id: `z${i}`,
      floor: 4,
      x: 3 + (i % 15) * 2.5,
      y: 3 + Math.floor(i / 15) * 3,
      hp: 60,
      path: [],
      repath: 0,
      cooldown: 0,
      memory: 0,
      stagger: 100,
      origin: "outside",
    });
  const old = g.zombies.map((z) => ({
    id: z.id,
    x: z.x,
    y: z.y,
    floor: z.floor,
  }));
  step(g, 1 / 30);
  assert.equal(g.spawned, 91);
  assert.equal(g.zombies.length, 91);
  assert.deepEqual(
    g.zombies
      .slice(0, 90)
      .map((z) => ({ id: z.id, x: z.x, y: z.y, floor: z.floor })),
    old,
  );
});
test("outside occupancy delays a batch without indoor substitutes, lost IDs or a later catch-up burst", () => {
  const g = fixture();
  g.floors[0].furniture.push({
    ...g.floors[0].furniture[0],
    id: "sealed-exterior",
    kind: "shelf",
    x: 22,
    y: 33.4,
    w: 8,
    h: 1,
  });
  step(g, 1 / 30);
  assert.equal(g.spawned, 90);
  assert.equal(g.zombies.length, 0);
  g.floors[0].furniture.pop();
  while (g.time < 1008.1) step(g, 1 / 30);
  assert.equal(g.zombies.length, 1);
  assert.equal(g.zombies[0].id, "z90");
});
test("reload retains the reinforcement deadline and exact next outside batch without a timer reroll", () => {
  const g = fixture();
  step(g, 1 / 30);
  const copy = decode(encode(g));
  for (let i = 0; i < 250; i++) {
    step(g, 1 / 30);
    step(copy, 1 / 30);
  }
  assert.equal(encode(copy), encode(g));
  assert.equal(g.spawned, 92);
});
