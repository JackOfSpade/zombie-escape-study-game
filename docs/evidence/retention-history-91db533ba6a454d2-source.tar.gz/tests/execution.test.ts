import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createGame } from "../src/world";
import { type Roadmap } from "../src/model";
import { initialLearner, reconcileGates } from "../src/learner";
import { initialStudy, eligible } from "../src/curriculum";
import { edit } from "../src/ai";
import { canRunWorkspace, runWorkspace } from "../src/execution";
import { sha256 } from "../src/roadmap-export";
import { step } from "../src/engine";
import { decode, encode, recover } from "../src/persistence";
const r: Roadmap = JSON.parse(readFileSync("public/curriculum.json", "utf8"));
function fixture() {
  const g = createGame(0, r);
  g.study = initialStudy(r, "live");
  // Synthetic gate history, confined to a test-mode ledger.
  const l = initialLearner(r, "test");
  for (const o of r.tracks.PY.objectives) l.cells[o.id].states[0] = "P";
  l.reviews = {};
  reconcileGates(r, l);
  g.study.learner = l;
  const contract = eligible(r, g.study);
  assert.equal(contract.depth, 2);
  const e = g.encounters["f0-room0"];
  e.problem = {
    title: "Synthetic executable task",
    prompt: "Transport fixture only",
    rubric: [],
    starter: "",
    provenance: "study-mode",
    contract,
    runtime: { language: "python" },
  };
  edit(g, e, "print(7)", 0);
  return { g, e, l };
}
test("runtime scope cannot raise the academic tier or make D1 implementation compulsory", async () => {
  const { g, e } = fixture();
  assert.equal(canRunWorkspace(g, e, r), true);
  e.problem!.contract.depth = 3;
  assert.equal(canRunWorkspace(g, e, r), false);
  await assert.rejects(runWorkspace(g, e, r), /eligible/);
  e.problem!.contract.depth = 1;
  assert.equal(canRunWorkspace(g, e, r), false);
  assert.equal(e.executions, undefined);
  assert.equal(g.study.learner!.evidence.length, 0);
});
test("mock transport: a running code snapshot stays exact while edits, survival and backups continue", async () => {
  const { g, e, l } = fixture(),
    originalFetch = globalThis.fetch;
  let reply!: (r: Response) => void;
  let entered!: () => void;
  const ready = new Promise<void>((resolve) => {
    entered = resolve;
  });
  globalThis.fetch = async () =>
    new Promise<Response>((resolve) => {
      reply = resolve;
      entered();
    });
  try {
    const pending = runWorkspace(g, e, r);
    await ready;
    const snapshot = e.workspace,
      revision = e.revision;
    assert.equal(e.executions!.length, 1);
    await runWorkspace(g, e, r);
    assert.equal(e.executions!.length, 1);
    edit(g, e, "print(8)", e.revision);
    g.survivors = g.survivors.slice(0, 1);
    g.status = "playing";
    g.nextSpawn = Number.MAX_SAFE_INTEGER;
    step(g, 1 / 30);
    assert.ok(g.time > 0);
    reply(
      new Response(
        JSON.stringify({
          id: "synthetic-receipt",
          language: "python",
          executed: true,
          status: "completed",
          codeHash: await sha256(snapshot),
          imageId: `sha256:${"0".repeat(64)}`,
          stdout: "7\n",
          stderr: "",
          exitCode: 0,
        }),
        { status: 200 },
      ),
    );
    await pending;
    const job = e.executions![0];
    assert.equal(job.code, snapshot);
    assert.equal(job.revision, revision);
    assert.equal(e.workspace, "print(8)");
    assert.equal(job.receipt!.stdout, "7\n");
    assert.equal(e.history.at(-1)!.revision, revision);
    assert.equal(e.history.at(-1)!.executionId, job.id);
    assert.deepEqual(
      e.history.at(-1)!.refs,
      job.artifactSequences.map((seq) => `artifact:${seq}`),
    );
    assert.deepEqual(
      decode(encode(g)).encounters[e.id].executions,
      e.executions,
    );
    assert.equal(e.state, "available");
    assert.equal(l.evidence.length, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
test("a receipt for different code is rejected without creating execution evidence", async () => {
  const { g, e } = fixture(),
    originalFetch = globalThis.fetch;
  globalThis.fetch = async () =>
    new Response(
      JSON.stringify({
        id: "wrong-code",
        language: "python",
        executed: true,
        status: "completed",
        codeHash: "wrong",
        imageId: `sha256:${"0".repeat(64)}`,
        stdout: "forged",
        stderr: "",
      }),
    );
  try {
    await runWorkspace(g, e, r);
    assert.equal(e.executions![0].status, "error");
    assert.ok(!e.history.some((h) => h.kind === "execution"));
    assert.match(e.executions![0].error!, /captured code/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
test("restart retains interrupted code snapshots in current and archived encounters without rerunning them", () => {
  const { g, e } = fixture();
  e.executions = [
    {
      id: "interrupted",
      language: "python",
      revision: e.revision,
      code: e.workspace,
      artifactSequences: [],
      status: "pending",
    },
  ];
  const archive = structuredClone(e);
  archive.runId = "archived-fixture";
  g.study.archives.push(archive);
  const restored = recover(decode(encode(g)));
  for (const encounter of [
    restored.encounters[e.id],
    restored.study.archives[0],
  ]) {
    assert.equal(encounter.executions![0].status, "interrupted");
    assert.equal(encounter.executions![0].code, "print(7)");
    assert.equal(encounter.executions![0].receipt, undefined);
  }
});
