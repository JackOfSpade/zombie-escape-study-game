import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createGame } from "../src/world";
import { eligible } from "../src/curriculum";
import { checkBridge, submit, retrySubmission, edit } from "../src/ai";
import { encode, decode, recover } from "../src/persistence";
import type { Roadmap } from "../src/model";
const roadmap: Roadmap = JSON.parse(
  readFileSync("public/curriculum.json", "utf8"),
);
function fixture() {
  const g = createGame(71, roadmap),
    e = g.encounters["f0-room0"];
  g.study.profile = "live";
  e.problem = {
    title: "Controlled retry",
    prompt: "Synthetic transport fixture",
    starter: "",
    rubric: [],
    provenance: "chatgpt-handoff",
    contract: eligible(roadmap, g.study),
  };
  e.workspace = "Original captured work";
  return { g, e };
}
async function connection(handler: typeof fetch) {
  const original = globalThis.fetch;
  globalThis.fetch = async (url, init) =>
    String(url) === "/api/status"
      ? Response.json({
          mode: "chatgpt-handoff",
          label: "Controlled handoff",
          detail: "Synthetic test transport only",
          capabilities: ["complete", "assess"],
        })
      : handler(url, init);
  await checkBridge();
  return async () => {
    globalThis.fetch = async () =>
      Response.json({
        mode: "development",
        label: "Development fallback",
        detail: "Fixture restored",
        capabilities: [],
      });
    await checkBridge();
    globalThis.fetch = original;
  };
}
test("saved completion retries the identical payload after edits and reload, coalesces calls and does not capture another submission", async () => {
  const { g, e } = fixture(),
    bodies: string[] = [];
  let finish: ((r: Response) => void) | undefined;
  const restore = await connection(async (_url, init) => {
    bodies.push(String(init?.body));
    if (bodies.length === 1)
      return Response.json({ error: "Controlled outage" }, { status: 503 });
    return new Promise<Response>((resolve) => {
      finish = resolve;
    });
  });
  try {
    await submit(g, e, roadmap);
    const id = e.submissions[0].id;
    assert.equal(e.submissions[0].status, "error");
    edit(g, e, "Later unsent edits", e.revision, roadmap);
    const loaded = recover(decode(encode(g))),
      resumed = loaded.encounters[e.id];
    const first = retrySubmission(loaded, resumed, roadmap, id),
      second = retrySubmission(loaded, resumed, roadmap, id);
    assert.equal(first, second);
    assert.equal(bodies.length, 2);
    assert.equal(bodies[1], bodies[0]);
    assert.equal(resumed.submissions.length, 1);
    assert.equal(resumed.workspace, "Later unsent edits");
    finish!(
      Response.json({
        complete: false,
        feedback: "Controlled needs-work result",
        qualified: [],
      }),
    );
    await first;
    assert.equal(resumed.submissions[0].status, "needs-work");
    assert.equal(resumed.workspace, "Later unsent edits");
    await retrySubmission(loaded, resumed, roadmap, id);
    assert.equal(bodies.length, 2);
  } finally {
    await restore();
  }
});
test("saved completion refuses a changed provider or captured revision before sending another request", async () => {
  const { g, e } = fixture();
  let calls = 0;
  const restore = await connection(async () => {
    calls++;
    return Response.json({ error: "Controlled outage" }, { status: 503 });
  });
  try {
    await submit(g, e, roadmap);
    const s = e.submissions[0],
      saved = s.completionRequest!;
    saved.provider = "study-mode";
    await retrySubmission(g, e, roadmap, s.id);
    assert.equal(calls, 1);
    assert.match(s.feedback, /original completion provider/);
    saved.provider = "chatgpt-handoff";
    g.study.profile = "development";
    await retrySubmission(g, e, roadmap, s.id);
    assert.equal(calls, 1);
    assert.equal(e.state, "in-progress");
    assert.match(s.feedback, /original completion provider/);
    g.study.profile = "live";
    const payload = JSON.parse(saved.payloadJson);
    payload.submission.content = "Changed after capture";
    saved.payloadJson = JSON.stringify(payload);
    await retrySubmission(g, e, roadmap, s.id);
    assert.equal(calls, 1);
    assert.match(s.feedback, /captured question and revision/);
    assert.equal(e.state, "in-progress");
    assert.equal(e.submissions.length, 1);
  } finally {
    await restore();
  }
});
