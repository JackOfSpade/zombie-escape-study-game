// Real queue/HTTP/stdio mechanics with synthetic answers, not native Study Mode.
import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtempSync,
  rmSync,
  readFileSync,
  writeFileSync,
  renameSync,
  chmodSync,
  lstatSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import type { Server } from "node:http";
// @ts-expect-error Direct .mjs transport test.
import { createHandoffQueue } from "../scripts/chatgpt-handoff-queue.mjs";
// @ts-expect-error Direct .mjs transport test.
import { createHandoffRoutes } from "../scripts/chatgpt-handoff-routes.mjs";
// @ts-expect-error Direct .mjs transport test.
import { createStudyBridgeServer } from "../scripts/study-bridge-server.mjs";
const worker = "synthetic-worker-one",
  other = "synthetic-worker-two";
const payload = (requestId: string) => ({
  requestId,
  problem: { prompt: "Synthetic task; never real learner proof" },
  messages: [{ text: "PRIVATE_SYNTHETIC_TUTOR_CONTEXT" }],
});

test("roadmap handoff binds both file hashes and retains its claim after malformed proposals", () => {
  const q = createHandoffQueue();
  const p = {
    requestId: "synthetic-roadmap",
    provider: "chatgpt-handoff",
    localHash: "local-hash",
    candidateHash: "incoming-hash",
    local: "local fixture",
    candidate: "incoming fixture",
    instruction: "Preserve source evidence",
  };
  assert.throws(() => q.enqueue("reconcile-roadmap", p), /disabled/);
  q.enable(true);
  const receipt = q.enqueue("reconcile-roadmap", p),
    job = q.get(worker);
  assert.equal(job.operation, "reconcile-roadmap");
  assert.deepEqual(job.payload, p);
  assert.match(job.instructions, /explicitly adopt/);
  const answer = {
    requestId: p.requestId,
    localHash: p.localHash,
    candidateHash: p.candidateHash,
    canonical: "# Complete synthetic proposal",
    definitions: [],
    mappings: [],
    completeScopes: [],
    decisions: [],
    rationale: "Local transport fixture only",
  };
  for (const bad of [
    { ...answer, localHash: "other" },
    { ...answer, candidateHash: "other" },
    { ...answer, requestId: "other" },
    { ...answer, canonical: "" },
    { ...answer, decisions: {} },
  ]) {
    assert.throws(
      () => q.submit(worker, job.jobId, job.claim, bad),
      /exact roadmap|complete canonical/,
    );
    assert.deepEqual(q.get(worker), job);
    assert.equal(q.result(receipt.id, receipt.hash).status, "pending");
  }
  assert.equal(
    q.submit(worker, job.jobId, job.claim, answer).status,
    "accepted",
  );
  assert.deepEqual(q.result(receipt.id, receipt.hash), {
    status: "done",
    answer,
  });
});

test("ChatGPT handoffs are explicitly released, prioritized, exact-request bound and once-only", () => {
  const q = createHandoffQueue();
  assert.throws(() => q.enqueue("tutor", payload("tutor-1")), /disabled/);
  q.enable(true);
  const background = q.enqueue("assess", payload("assessment-1")),
    foreground = q.enqueue("tutor", payload("tutor-1"));
  assert.deepEqual(q.enqueue("tutor", payload("tutor-1")), foreground);
  assert.throws(
    () => q.enqueue("tutor", { ...payload("tutor-1"), changed: true }),
    /Conflicting/,
  );
  assert.throws(() => q.enqueue("run-code", payload("bad")), /Unsupported/);
  const job = q.get(worker);
  assert.equal(job.jobId, foreground.id);
  assert.equal(job.operation, "tutor");
  assert.deepEqual(
    q.get(worker),
    job,
    "repeated pulls return the exact owned job",
  );
  assert.equal(
    q.get(other).jobId,
    background.id,
    "workers never claim the same request",
  );
  assert.throws(
    () => q.submit(other, job.jobId, job.claim, { text: "wrong worker" }),
    /Wrong worker/,
  );
  assert.throws(() => q.submit(worker, job.jobId, job.claim, {}), /nonempty/);
  assert.deepEqual(q.result(foreground.id, foreground.hash), {
    status: "pending",
  });
  assert.equal(
    q.submit(worker, job.jobId, job.claim, {
      text: "Which assumption needs checking?",
    }).status,
    "accepted",
  );
  assert.equal(
    q.submit(worker, job.jobId, job.claim, {
      text: "Which assumption needs checking?",
    }).status,
    "duplicate",
  );
  assert.throws(
    () => q.submit(worker, job.jobId, job.claim, { text: "Rerolled answer" }),
    /Conflicting duplicate/,
  );
  assert.throws(() => q.result(foreground.id, "wrong-hash"), /Unknown exact/);
  assert.match(job.instructions, /Native|native/);
  assert.match(job.instructions, /untrusted evidence/);
  q.enable(false);
  assert.throws(() => q.result(foreground.id, foreground.hash), /disabled/);
});

test("interrupted handoffs retain exact jobs and answers; authorization does not survive restart and requeue invalidates stale claims", () => {
  const dir = mkdtempSync(join(tmpdir(), "dead-air-handoff-")),
    file = join(dir, "jobs.json");
  try {
    let q = createHandoffQueue({ file });
    q.enable(true);
    const receipt = q.enqueue("tutor", payload("durable")),
      job = q.get(worker);
    assert.equal(lstatSync(file).mode & 0o777, 0o600);
    q = createHandoffQueue({ file });
    assert.equal(q.snapshot().enabled, false);
    assert.throws(() => q.get(worker), /disabled/);
    q.enable(true);
    assert.deepEqual(q.get(worker), job);
    q.requeueWorking();
    const replacement = q.get(other);
    assert.equal(replacement.jobId, job.jobId);
    assert.notEqual(replacement.claim, job.claim);
    assert.throws(
      () => q.submit(worker, job.jobId, job.claim, { text: "late" }),
      /Wrong worker/,
    );
    q.submit(other, replacement.jobId, replacement.claim, {
      text: "Retained answer",
    });
    q = createHandoffQueue({ file });
    q.enable(true);
    assert.deepEqual(q.result(receipt.id, receipt.hash), {
      status: "done",
      answer: { text: "Retained answer" },
    });
    const before = q.snapshot(),
      disk = readFileSync(file, "utf8");
    renameSync(dir, dir + "-moved");
    assert.throws(() => q.enqueue("tutor", payload("write-failed")));
    assert.deepEqual(
      q.snapshot(),
      before,
      "failed durable writes must roll back memory",
    );
    renameSync(dir + "-moved", dir);
    assert.equal(readFileSync(file, "utf8"), disk);
    chmodSync(file, 0o644);
    assert.throws(() => createHandoffQueue({ file }), /Unsafe/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
    rmSync(dir + "-moved", { recursive: true, force: true });
  }
});

async function listen(server: Server) {
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const addr = server.address();
  assert.ok(addr && typeof addr !== "string");
  return `http://127.0.0.1:${addr.port}`;
}
async function close(server: Server) {
  server.closeAllConnections();
  await new Promise<void>((resolve) => server.close(() => resolve()));
}

test("actual loopback relay queues ChatGPT work without claiming native Study Mode and rejects cross-origin release or unauthorized workers", async () => {
  const q = createHandoffQueue(),
    handoff = createHandoffRoutes(q, { token: "synthetic-test-token" }),
    server = createStudyBridgeServer({ handoff }),
    base = await listen(server);
  const post = (
    path: string,
    body: unknown,
    headers: Record<string, string> = {},
  ) =>
    fetch(base + path, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...headers },
      body: JSON.stringify(body),
    });
  try {
    assert.equal(
      (await (await fetch(base + "/api/status")).json()).mode,
      "development",
    );
    assert.equal(
      (
        await post(
          "/api/handoff/control",
          { action: "enable", enabled: true },
          { Origin: "http://localhost:9999" },
        )
      ).status,
      403,
    );
    assert.equal(
      (
        await post(
          "/api/handoff/control",
          { action: "enable", enabled: true },
          { Origin: "http://127.0.0.1:5173" },
        )
      ).status,
      200,
    );
    const status = await (await fetch(base + "/api/status")).json();
    assert.equal(status.mode, "chatgpt-handoff");
    assert.match(status.detail, /not verified/);
    assert.match(status.detail, /no OpenAI API calls/);
    const response = await post(
      "/api/bridge",
      { operation: "tutor", payload: payload("http-tutor") },
      { Origin: "http://127.0.0.1:5173" },
    );
    assert.equal(response.status, 202);
    const { handoff: receipt } = await response.json();
    assert.equal(
      (await post("/api/handoff/worker", { action: "get", worker })).status,
      403,
    );
    assert.equal(
      (
        await post(
          "/api/handoff/worker",
          { action: "get", worker },
          {
            Authorization: "Bearer synthetic-test-token",
            Origin: "http://127.0.0.1:5173",
          },
        )
      ).status,
      403,
    );
    const auth = { Authorization: "Bearer synthetic-test-token" };
    const job = await (
      await post("/api/handoff/worker", { action: "get", worker }, auth)
    ).json();
    assert.equal(job.payload.requestId, "http-tutor");
    const resultUrl = `${base}/api/bridge/result?id=${receipt.id}&hash=${receipt.hash}`;
    assert.equal((await fetch(resultUrl)).status, 202);
    assert.equal(
      (
        await post(
          "/api/handoff/worker",
          {
            action: "submit",
            worker,
            jobId: job.jobId,
            claim: job.claim,
            answer: {},
          },
          auth,
        )
      ).status,
      409,
    );
    assert.equal(
      (
        await post(
          "/api/handoff/worker",
          {
            action: "submit",
            worker,
            jobId: job.jobId,
            claim: job.claim,
            answer: { text: "Explain the boundary." },
          },
          auth,
        )
      ).status,
      200,
    );
    assert.deepEqual(await (await fetch(resultUrl)).json(), {
      text: "Explain the boundary.",
    });
    const summary = await (await fetch(base + "/api/handoff/status")).text();
    assert.ok(!summary.includes("PRIVATE_SYNTHETIC"));
  } finally {
    await close(server);
  }
});

test("actual stdio MCP worker pulls and submits only its correlated local handoff", async () => {
  const dir = mkdtempSync(join(tmpdir(), "dead-air-mcp-")),
    tokenFile = join(dir, "worker-token");
  writeFileSync(tokenFile, "synthetic-stdio-token", { mode: 0o600 });
  const q = createHandoffQueue();
  q.enable(true);
  const receipt = q.enqueue("tutor", payload("stdio-tutor"));
  const server = createStudyBridgeServer({
      handoff: createHandoffRoutes(q, { token: "synthetic-stdio-token" }),
    }),
    base = await listen(server);
  const child = spawn(process.execPath, ["scripts/chatgpt-handoff-mcp.mjs"], {
    env: {
      ...process.env,
      DEAD_AIR_RELAY_URL: base,
      DEAD_AIR_TOKEN_FILE: tokenFile,
    },
    stdio: ["pipe", "pipe", "pipe"],
  });
  const waiting = new Map<
    number,
    { resolve: (v: any) => void; reject: (e: Error) => void }
  >();
  let sequence = 0;
  const lines = createInterface({ input: child.stdout });
  let stderr = "";
  child.stderr.on("data", (part) => {
    stderr += part;
  });
  lines.on("line", (line) => {
    const value = JSON.parse(line);
    waiting.get(value.id)?.resolve(value);
    waiting.delete(value.id);
  });
  const rpc = (method: string, params?: unknown) =>
    new Promise<any>((resolve, reject) => {
      const id = ++sequence;
      waiting.set(id, { resolve, reject });
      child.stdin.write(
        JSON.stringify({ jsonrpc: "2.0", id, method, params }) + "\n",
      );
    });
  const timeout = setTimeout(() => {
    for (const p of waiting.values()) p.reject(Error("MCP test timeout"));
  }, 10_000);
  try {
    const init = await rpc("initialize", { protocolVersion: "2025-11-25" });
    assert.equal(init.result.serverInfo.name, "dead-air-chatgpt-handoff");
    const list = await rpc("tools/list");
    assert.deepEqual(
      list.result.tools.map((t: any) => t.name),
      ["get_study_handoff", "submit_study_handoff", "read_study_handoff_part"],
    );
    const reply = await rpc("tools/call", {
        name: "get_study_handoff",
        arguments: {},
      }),
      job = JSON.parse(reply.result.content[0].text);
    assert.equal(job.payload.requestId, "stdio-tutor");
    const submitted = await rpc("tools/call", {
      name: "submit_study_handoff",
      arguments: {
        jobId: job.jobId,
        claim: job.claim,
        response: JSON.stringify({ text: "Controlled stdio guidance" }),
      },
    });
    assert.equal(
      JSON.parse(submitted.result.content[0].text).status,
      "accepted",
    );
    assert.deepEqual(q.result(receipt.id, receipt.hash).answer, {
      text: "Controlled stdio guidance",
    });
    assert.ok(!stderr.includes("synthetic-stdio-token"));
  } finally {
    clearTimeout(timeout);
    child.kill("SIGTERM");
    lines.close();
    await close(server);
    rmSync(dir, { recursive: true, force: true });
  }
});

test("large packets require every stable Unicode-preserving part before a response can be submitted", () => {
  const q = createHandoffQueue();
  q.enable(true);
  const source = {
    ...payload("large-tutor"),
    context: "Exact private context 🙂 boundary\n".repeat(50_000),
  };
  const receipt = q.enqueue("tutor", source),
    job = q.get(worker);
  assert.equal(job.payload, undefined);
  assert.equal(job.payloadManifest.format, "chunked-json");
  assert.throws(
    () =>
      q.submit(worker, job.jobId, job.claim, {
        text: "Unjustified partial review",
      }),
    /every payload part/,
  );
  assert.throws(() => q.part(other, job.jobId, job.claim, 0), /Wrong worker/);
  const parts = [];
  for (let index = 0; index < job.payloadManifest.parts; index++) {
    const part = q.part(worker, job.jobId, job.claim, index);
    assert.equal(part.payloadSha256, job.payloadManifest.sha256);
    parts.push(part.text);
    assert.ok(Buffer.byteLength(JSON.stringify(part)) < 300_000);
  }
  assert.deepEqual(JSON.parse(parts.join("")), source);
  q.submit(worker, job.jobId, job.claim, {
    text: "Complete packet was available for this controlled reply",
  });
  assert.equal(q.result(receipt.id, receipt.hash).status, "done");
});

test("explicit corrected replies retain the exact original request and previous answer while invalidating stale submissions", () => {
  const q = createHandoffQueue();
  q.enable(true);
  const receipt = q.enqueue("tutor", payload("correction")),
    job = q.get(worker);
  q.submit(worker, job.jobId, job.claim, { text: "First controlled reply" });
  q.reopen(job.jobId);
  assert.equal(q.result(receipt.id, receipt.hash).status, "pending");
  const corrected = q.get(worker);
  assert.equal(corrected.jobId, job.jobId);
  assert.equal(corrected.requestHash, job.requestHash);
  assert.deepEqual(corrected.payload, job.payload);
  assert.notEqual(corrected.claim, job.claim);
  assert.equal(corrected.correction.round, 1);
  assert.ok(
    !JSON.stringify(corrected.correction).includes("First controlled reply"),
  );
  assert.throws(
    () =>
      q.submit(worker, job.jobId, job.claim, {
        text: "Late first-round result",
      }),
    /Wrong worker/,
  );
  q.submit(worker, corrected.jobId, corrected.claim, {
    text: "Corrected controlled reply",
  });
  assert.deepEqual(q.result(receipt.id, receipt.hash).answer, {
    text: "Corrected controlled reply",
  });
});

test("interactive priority ages fairly and completed requests do not impose an artificial per-session tutoring count", () => {
  let now = 0;
  const q = createHandoffQueue({ now: () => now, maxJobs: 1 });
  q.enable(true);
  for (let i = 0; i < 4; i++) {
    q.enqueue("tutor", payload(`done-${i}`));
    const job = q.get(worker);
    q.submit(worker, job.jobId, job.claim, { text: "Controlled answer" });
  }
  assert.equal(q.snapshot().done, 4);
  const aged = createHandoffQueue({ now: () => now });
  aged.enable(true);
  const background = aged.enqueue("assess", payload("old-assessment"));
  now = 150_000;
  aged.enqueue("tutor", payload("new-tutor"));
  assert.equal(aged.get(worker).jobId, background.id);
});

test("generation rejects rubric objects before accepting a reply and retains the same claim for a corrected string rubric", () => {
  const q = createHandoffQueue();
  q.enable(true);
  const contract = {
    id: "synthetic-format",
    objectiveIds: ["SYNTHETIC:EMPTY"],
    depth: 1,
  };
  const receipt = q.enqueue("generate", {
    requestId: "synthetic-rubric-format",
    contract,
  });
  const job = q.get(worker);
  const answer = {
    title: "Fictional boundary",
    prompt: "Which boundary needs checking?",
    starter: "",
    rubric: [{ facetId: "boundary", criterion: "Explain the empty case" }],
    contract,
    scopeDefinitions: [
      { id: "synthetic", objectiveId: "SYNTHETIC:EMPTY", facets: [] },
    ],
  };
  assert.match(job.instructions, /rubric is an array of strings/);
  assert.throws(
    () => q.submit(worker, job.jobId, job.claim, answer),
    /rubric as an array of strings/,
  );
  assert.deepEqual(q.result(receipt.id, receipt.hash), { status: "pending" });
  assert.equal(q.get(worker).claim, job.claim);
  assert.equal(
    q.submit(worker, job.jobId, job.claim, {
      ...answer,
      rubric: ["boundary: Explain the empty case"],
    }).status,
    "accepted",
  );
  assert.equal(
    q.result(receipt.id, receipt.hash).answer.rubric[0],
    "boundary: Explain the empty case",
  );
});

test("group reply rejects string references and changed revisions while retaining its exact request and claim", () => {
  const q = createHandoffQueue();
  q.enable(true);
  const receipt = q.enqueue("group", {
    requestId: "synthetic-reference-format",
    mode: "reply",
    sourceRevision: 3,
    events: [{ seq: 12, author: "human", kind: "reasoning" }],
  });
  const job = q.get(worker),
    answer = {
      requestId: "synthetic-reference-format",
      sourceRevision: 3,
      messages: [
        {
          author: "synthetic-robin",
          kind: "question",
          text: "Which boundary?",
          refs: ["message:12"],
        },
      ],
    };
  assert.throws(
    () => q.submit(worker, job.jobId, job.claim, answer),
    /integer sequence numbers/,
  );
  assert.throws(
    () =>
      q.submit(worker, job.jobId, job.claim, {
        ...answer,
        sourceRevision: 4,
        messages: [],
      }),
    /Preserve sourceRevision/,
  );
  assert.deepEqual(q.result(receipt.id, receipt.hash), { status: "pending" });
  assert.equal(q.get(worker).claim, job.claim);
  assert.equal(
    q.submit(worker, job.jobId, job.claim, {
      ...answer,
      messages: [{ ...answer.messages[0], refs: [12] }],
    }).status,
    "accepted",
  );
});
