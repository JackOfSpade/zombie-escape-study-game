import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { createStudyBridgeServer } from "./study-bridge-server.mjs";
import { createHandoffQueue } from "./chatgpt-handoff-queue.mjs";
import { createHandoffRoutes } from "./chatgpt-handoff-routes.mjs";
import { createPublicHandoffBridge } from "./chatgpt-public-bridge.mjs";
import { createTunnelSupervisor } from "./chatgpt-tunnel-supervisor.mjs";
import {
  loadGameTunnelConfig,
  tunnelDirectory,
} from "./chatgpt-tunnel-config.mjs";
const handoffDirectory = new URL("../.local/chatgpt-handoff/", import.meta.url);
const queue = createHandoffQueue({
  file: fileURLToPath(new URL("jobs.json", handoffDirectory)),
});
let publicBridge, supervisor;
try {
  const config = loadGameTunnelConfig();
  publicBridge = createPublicHandoffBridge({
    hostname: config.hostname,
    queue,
    directory: tunnelDirectory,
    connectorRanges: config.connectorRanges,
  });
  supervisor = createTunnelSupervisor(config);
} catch (error) {
  if (error.code !== "ENOENT")
    console.error(
      "Public game connector configuration needs repair. Local play remains available.",
    );
}
const handoff = createHandoffRoutes(queue, {
  tokenFile: fileURLToPath(new URL("worker-token", handoffDirectory)),
  publicBridge,
  supervisor,
});
const server = createStudyBridgeServer({
  handoff,
  endpoint: process.env.STUDY_MODE_BRIDGE_URL,
  key: process.env.STUDY_MODE_BRIDGE_TOKEN,
});
await new Promise((resolve, reject) => {
  server.once("error", reject);
  server.listen(4318, "127.0.0.1", resolve);
});
if (publicBridge) {
  try {
    await publicBridge.listen();
  } catch {
    console.error(
      "Public game connector socket could not open. Tunnel remains stopped.",
    );
    supervisor = undefined;
  }
}
console.log("Study bridge relay: http://127.0.0.1:4318 (loopback only)");
const vite = spawn(
  process.execPath,
  [
    fileURLToPath(new URL("../node_modules/vite/bin/vite.js", import.meta.url)),
    "--host",
    "127.0.0.1",
  ],
  { stdio: "inherit" },
);
let closing = false;
async function close(signal = "SIGTERM") {
  if (closing) return;
  closing = true;
  vite.kill(signal);
  await supervisor?.stop();
  await publicBridge?.close();
  server.closeAllConnections();
  server.close(() => process.exit(0));
}
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => {
    void close(signal);
  });
vite.on("exit", () => {
  void close();
});
